---
name: restart-window-bundling
description: Classify runtime impact and require the included updater.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [development, restart, maintenance-window, deployment, activation, rollback, fail-closed]
    related_skills: [repository-build-verification, hermes-safe-change-verification, gateway-maintenance-drain-operations]
---

# Restart Impact and Included Updater Skill

Classify runtime impact and use the installation's supported lifecycle commands. The skill name remains stable because Kanban workers preload it.

## Mandatory Hermes update policy

For Hermes application updates, use the updater included with the installation: `hermes update` for an admitted source checkout, the built-in Desktop update flow for bundles, or the owning package/image manager where Hermes directs it. This is mandatory, not a preference. Do not substitute a manual live checkout/reset/copy, release-directory switch, or bespoke deployment controller. Prepare fork merges and tests in an isolated checkout, then publish through the authorized delivery workflow so the included updater can consume the intended feed.

This policy supersedes older Hermes-update instructions in this skill and its references that require sealed bundles, an external activation controller, a fixed 180-second handoff, separate activation cards, or suppressing the updater's own restart. Those procedures apply only to explicitly selected legacy recovery/custom-controller work; they are not prerequisites for an ordinary update. A clear user request to update/deploy the identified installation can authorize its documented restart; reuse that authorization rather than repeatedly asking. Confirm only missing scope or effects beyond it. Keep lifecycle guards, locks, leases, identity checks and user restrictions intact.

Before invocation, verify the installed updater's help/source, installation path/type, target feed/revision, affected profiles/services, dirty changes, backup/recovery path and actual update scope. Do not invent flags or assume `--yes` grants permission. A no-restart flag does not make mutation of a running source checkout safe. An exported release without supported updater metadata needs a separately scoped migration to a supported installation; report that incompatibility rather than building another controller. Verify the resulting source/runtime identity, health and changed behavior, and report warnings or incomplete recovery honestly.

## When to Use

Use for development, review and deployment work that may affect a running process. Documentation-only changes and isolated development do not authorize or require a service restart.

## Prerequisites

Identify the target installation and its current user authorization. Inspect files with `read_file` and locate relevant updater code and documentation with `search_files`; use `terminal` for the installed CLI's supported diagnostics.

## How to Run

1. Record runtime impact: `restart_free`, `reload_only`, `restart_required`, `host_reboot_required`, or `unknown`. Treat unknown as potentially disruptive, not as a reason to invent deployment machinery.
2. Prepare and test source changes outside the running checkout. Record target processes, evidence and a practical recovery identity/path. Derive these fields from available evidence; ask only for missing material scope.
3. For an authorized Hermes source update, invoke the included updater once with verified options for the intended feed. Let it own its checkout, dependency preparation and restart sequence. Do not interleave another writer or wrap it in a competing drain/stop/start controller.
4. Verify updater receipts, warnings, resulting source/runtime identity, affected services and changed behavior. Preserve failure evidence and use the documented recovery path.

## Quick Reference

- Application source update: `hermes update` (verify installed semantics first).
- Package-owned application: the owning updater, as documented for that installation.
- Restart-only/config activation: the supported lifecycle command for that runtime; no source switching.
- Unsupported exported release: prepare a supported migration plan; do not fabricate Git metadata.
- Host reboot: separate scope from an application update.

## Procedure

Record `Restart impact`, `Target processes`, `Activation grouping`, `Evidence` and `Rollback identity` in operational handoffs. `Activation grouping: included-updater` is valid; no sealed manifest is required. Existing user authorization persists within its stated scope. A changed target or a larger service fleet requires reconciling scope before mutation.

The updater may pause gateways before source/dependency changes, resume them before product builds, or migrate compatible profiles. Verify the installed version's behavior rather than imposing an incompatible all-builds-before-outage rule. If its behavior cannot satisfy the user's constraints, report the concrete limitation and prepare a supported resolution. Never silently accept a broader fleet update or a failed pause that violates the agreed scope.

The scripts, templates and acceptance reference retained in this directory describe the older explicit bundle workflow. Load them only when the user has selected that legacy workflow or needs its recovery evidence. They do not govern normal Hermes updates and are not an alternative deployment route by default.

## Pitfalls

- Requiring a new controller, sealed bundle or repeated approval merely because an update restarts a gateway.
- Treating `--no-gateway-restart` as isolation from live source changes.
- Reusing old host, PID, service or feed identities as current evidence.
- Bypassing a tool lifecycle rejection through another executor, altered environment or encoded command.
- Claiming automatic full rollback: verify what the installed updater actually recovers.

## Verification

Report source preparation/publication, updater execution, runtime activation and observation separately. A healthy process is not proof of the requested Telegram behavior; run the relevant acceptance check when deployment is authorized. Policy/skill edits alone do not deploy application code.
