---
name: restart-window-bundling
description: Use in every development workflow to classify restarts.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [development, restart, maintenance-window, deployment, activation, rollback, fail-closed]
    related_skills: [repository-build-verification, hermes-safe-change-verification, gateway-maintenance-drain-operations]
---

# Restart-Window Bundling

## Purpose

Apply a **prepare continuously, activate once** policy to every development workflow. Development, review, merge, packaging, and preflight continue without forcing avoidable service restarts. Changes that require a process boundary accumulate in a restart queue and are activated as one immutable, reviewed bundle during an approved maintenance window.

This skill governs classification and packaging. It does not itself authorize a merge, deployment, restart, intake pause, or host reboot.

## When to use

Load this skill for every software-development plan, implementation, code review, PR, release, deployment, updater, plugin activation, dependency change, or configuration change that could affect a running process. It is still applicable when the expected verdict is `restart_free`, because that classification must be explicit and evidenced.

## Mandatory entry gate for every development change

Before implementation, classify the expected runtime effect:

- `restart_free`: documentation, tests, inactive code, or independently reloadable state that can be proven active without restarting the target process;
- `reload_only`: supported bounded reload with explicit runtime readback and no process replacement;
- `restart_required`: code, dependency, plugin, configuration, environment, or process-lifetime state that is imported/read only at process start;
- `host_reboot_required`: kernel, firmware, driver, or host lifecycle work; keep separate from application restart bundles unless the user explicitly approves a combined maintenance plan;
- `unknown`: evidence is insufficient. Treat as `restart_required` until proven otherwise.

Record the classification and evidence in the issue/card/plan/PR handoff. Reclassify whenever scope changes.

## Core invariants

1. Prepare and verify all expensive work before the outage: merges, conflict resolution, downloads, builds, dependency installation, review, and broad tests.
2. A restart bundle points to immutable artifacts: full commit/tree IDs, image or package digests, plugin-generation manifests, configuration hashes, and rollback identities.
3. Bundle revisions are append-never. Once `READY_NOT_EXECUTED` is sealed, any changed target, patch, test, service scope, controller, rollback artifact, or acceptance plan creates a new revision and requires fresh aggregate verification and approval.
4. Restart approval applies only to the exact sealed revision. Approval does not float to a newer candidate.
5. Activate the complete bundle once. Never install patches incrementally while services are down.
6. Rollback is bundle-wide. Do not selectively remove one patch from a failed, jointly tested generation during the outage.
7. The activation controller runs outside the service being restarted.
8. Runtime activation and observation are separate verdicts. A healthy new PID is not natural-traffic acceptance.
9. Host OS/kernel/firmware work is a separate failure domain and separate gate by default.
10. Urgent security or incident remediation may bypass normal batching only with an explicit reason and independent rollback/acceptance evidence.

## Development workflow

### 1. Classify and queue

For each change record:

- component and repository;
- exact candidate identity;
- restart classification and evidence;
- compatibility dependencies;
- tests and independent review state;
- target services/processes;
- rollback artifact;
- urgency and desired window.

Deploy `restart_free` changes through their normal verified path. Queue `restart_required` and `unknown` changes. A `reload_only` change may use a separately approved `reload` lifecycle with no stop/start/process replacement, or join a coordinated reload bundle. Keep `host_reboot_required` in a separate host bundle unless the user explicitly authorizes combining failure domains.

### 2. Compose an aggregate candidate

At the maintenance cutoff:

1. Select only approved, review-complete entries.
2. Resolve compatibility and ordering before sealing.
3. Build immutable artifacts and dependencies outside the live checkout/runtime.
4. Run focused tests for every entry plus aggregate integration tests for the exact combination.
5. Capture the current generation as the complete rollback target.
6. Generate a bundle manifest from `templates/restart-window-bundle.json`.
7. Validate it with `scripts/validate_bundle.py`.
8. Compute `seal.payload_sha256` over the canonical JSON serialization (`sort_keys=True`, compact separators, UTF-8) of exactly: `schema_version`, `bundle_id`, `bundle_revision`, `created_at`, `cutoff_at`, `before`, `target`, `changes`, `services`, `aggregate_verification`, `rollback`, `controller`, and `execution`.
9. Bind approval to the exact `bundle_id`, positive integer revision, sealed-payload digest, external-controller digest, rollback-manifest digest, approving identity, and UTC approval timestamp. Then seal the candidate as `READY_NOT_EXECUTED`.

Evidence entries are objects with non-empty `kind` and `identity` plus a 64-character lowercase SHA-256; strings such as `sha256=abc`, nulls, and unhashed evidence are invalid. The rollback artifact-name set must exactly equal the complete `before` generation and its restore-smoke evidence must pass before sealing.

Do not call a queue of individually passing patches a bundle until the aggregate candidate has passed compatibility tests.

### 3. Maintenance-window execution

Use `gateway-maintenance-drain-operations` or the target platform's equivalent:

1. Re-read approval and exact sealed identity immediately before execution.
2. Verify current runtime equals the declared `before`/rollback generation.
3. Verify remote refs and every local artifact hash; any drift blocks activation.
4. Pause only approved intake and autoheal/supervisor surfaces.
5. Drain existing work to one bounded monotonic deadline.
6. Follow exactly one mode-specific lifecycle:
   - `restart`: stop once, require every old `MainPID=0`, atomically switch the complete target, and start once;
   - `reload`: invoke the supported reload once and prohibit stop/start/process replacement;
   - `host_reboot`: use the separately approved host-reboot lifecycle and never mix ordinary application-restart changes by default.
7. Prove the complete runtime artifact set equals the declared target.
8. Run every named immediate canary and preserve hashed evidence.
9. Restore intake and supervision only after readback.
10. Write an atomic result record.

The validator accepts only the exact ordered lifecycle for the declared mode. Null/blank/extra steps, multiple restart commands, or package-manager/build/download/Git-preparation commands block validation. No Git merging, package building, dependency downloading, or broad test execution belongs inside the outage window.

### 4. Rollback

On a post-mutation failure:

- first prove the failed target generation is stopped;
- if it cannot be stopped, block source rollback to avoid mixing old bytes with a running new process;
- restore the complete previous artifact set;
- restart and verify the previous generation;
- preserve the failed result and evidence rather than overwriting it with retry output.

Before sealing, prove that `rollback.generation_identity` resolves to the declared `before` generation, `rollback.artifacts` exactly covers every `before` artifact, `rollback.manifest_sha256` equals the canonical SHA-256 of the complete `before` object, and a hashed `restore-smoke` record bound to the rollback generation is `PASS`. Arbitrary PASS evidence is not rollback proof.

A retry is a new execution record. A changed candidate is a new bundle revision.

### 5. Acceptance and closeout

Report independently:

- `queue`: included, excluded, deferred, and restart-free changes;
- `bundle`: exact manifest/controller/artifact hashes and aggregate tests;
- `authorization`: merge, deployment, intake pause, restart, and reboot gates;
- `shutdown`: old-generation drain/quiescence;
- `activation`: new runtime identity and immediate canaries;
- `observation`: natural traffic/scheduled cycles over the declared window;
- `rollback`: available, attempted, passed, blocked, or not needed.

`bundle_state=PASS` requires exactly one activation/reload, mode-correct shutdown evidence (`PASS` for restart/reboot, `NOT_APPLICABLE` for reload), exact target runtime hashes with unique artifact names, an `activation-result` receipt bound to bundle ID/revision, controller digest, execution identity, and target generation, all required canaries passing with hashed evidence, observed duration meeting the immutable `acceptance_plan`, and explicit rollback disposition. `READY_NOT_EXECUTED` requires a pending result; `ROLLED_BACK` requires a rollback result and must never validate as operational PASS. Close the bundle only after the defined natural observation passes. Keep deferred queue entries for a future revision; do not silently mark them deployed.

## Integration with plans, cards, PRs, and agents

Every development plan/card/agent brief must contain a `Restart impact` section:

```text
Restart impact: restart_free | reload_only | restart_required | host_reboot_required | unknown
Target processes: ...
Activation grouping: standalone | bundle:<id> | deferred
Evidence: ...
Rollback identity: ...
```

Every implementation handoff must state whether code was merely built, queued, sealed, activated, or observed. Terms such as `done`, `deployed`, and `live` must not collapse these states.

## Bundle artifacts

This skill includes:

- `templates/restart-window-bundle.json` — portable manifest skeleton;
- `scripts/validate_bundle.py` — deterministic structural and safety validator;
- `scripts/test_validate_bundle.py` — positive and fail-closed regression tests;
- `references/astra-remediation-acceptance.md` — frozen F01–F14 acceptance matrix and worker-surface inventory.

Use SHA-256 for file/artifact sealing. Keep secrets out of manifests; record credential/service key names only. The validator scans sensitive key names and credential-shaped string values, and diagnostics report only field paths—not rejected values. Run Python checks with `-B` or remove generated `__pycache__` before whole-tree parity claims; maintained-source parity excludes generated bytecode only when stated explicitly.

## Pitfalls

- Restarting after each merged patch because the updater offers to do so.
- Treating individually green PRs as aggregate compatibility evidence.
- Reusing approval after target SHA, service scope, or controller changes.
- Running the controller from the gateway/service it must stop.
- Building a venv or pulling packages while the service is down.
- Combining application and host-reboot work by convenience rather than explicit approval.
- Calling new-process health a complete observation verdict.
- Rolling source bytes back while a failed target process may still have them loaded.
