# GPT-6 Astra remediation acceptance matrix

Audit source: `@session:default/20260906_162318_9d9e97` against candidate `e9e94242f9d4496eb0ee3bdfc10a5a1e41ee610c`.

This matrix freezes the fourteen findings as acceptance requirements. A checked box means the remediation exists in the candidate; publication and re-audit remain separate gates.

| Finding | Acceptance requirement | Candidate remediation | Verification |
|---|---|---|---|
| F01 | Every actual development worker receives the gate independent of workspace `AGENTS.md` discovery or mutable profile inventory. | The dispatcher force-loads `kanban-worker` and `restart-window-bundling` into every spawned worker, preserves/de-duplicates task-specific skills, and profile synchronization remains defense in depth. Development cards carry the five-field contract. | RED→GREEN spawn-argv regression plus enumeration/readback of route-target profile copies. Runtime activation remains a separate fork-promotion gate. |
| F02 | Updater, planning, PR, config, preview, review, TDD, delegation, and Kanban procedures require classification and deferred activation. | Integrate the gate into the canonical workflow skills and remove the `install-local.sh` restart recommendation. | Semantic search every named skill for `restart-window-bundling`, `Restart impact`, and activation-state separation. |
| F03 | Canonical, default-runtime, and maintained profile copies are current; the DevOps manifest is truthful. | Publish previously runtime-only workflow skills; synchronize maintained profiles; regenerate the DevOps manifest from actual installed `SKILL.md` files. | Declared count equals actual count; source/destination SHA-256 pairs match. |
| F04 | A sealed candidate and approval are cryptographically bound to exact immutable inputs. | Canonical sealed-payload SHA-256 covers the revision, artifact generations, changes, services, aggregate evidence, rollback, controller, execution recipe, and acceptance plan. Approval binds bundle ID/revision and payload/controller/rollback digests plus approver/timestamp. | Regression cases reject malformed digest, acceptance-plan/payload drift, and every stale approval binding. |
| F05 | Rollback resolves to the complete previous generation and is verified before sealing. | Require rollback generation identity, canonical digest of the complete `before` object, exact equality with `before` artifact names, and hashed `restore-smoke` PASS evidence bound to that generation. | Regression cases reject unknown/incomplete rollback, arbitrary PASS evidence, digest mismatch, and pending verification. |
| F06 | Window execution is controller-bound, authorized, preparation-free, ordered, and single-activation. | Require identified external controller digest, explicit intake authorization, exact mode-specific lifecycle, positive non-boolean drain limit, and reject null/extra/package/build/Git steps. | Regression cases reject denied intake, null steps, install commands, reordered steps, and multiple restarts. |
| F07 | PASS proves activation, runtime identity, canaries, observation, and rollback disposition. | Require exactly one activation/reload, mode-correct shutdown evidence, unique exact target runtime hashes, an activation receipt bound to bundle/revision/controller/execution/target generation, all named canaries, immutable minimum observation duration, and `NOT_NEEDED` rollback disposition. State/result consistency is explicit for pending and rollback states. | PASS fixture succeeds; duplicate-name overwrite, unrelated receipt, stale binding, shortened observation, and contradictory states are rejected separately. |
| F08 | `reload_only` never uses process replacement. | Define a distinct exact reload lifecycle with `reload-once` and no stop/start/MainPID transition; require explicit reload approval and false restart approval. | Restart recipe under reload mode is rejected; valid reload lifecycle passes. |
| F09 | Credential-shaped values are rejected and diagnostics never echo them. | Scan sensitive key names and credential-shaped values recursively across HTTP(S), SSH, Git, FTP/SFTP, token, and private-key forms; diagnostics identify field paths or stable error classes only. | Synthetic secrets in ordinary fields, duplicate identifiers, sensitive key names, and SSH-style URIs are rejected and absent from validator/CLI stdout and stderr. |
| F10 | Malformed values deterministically BLOCK; booleans do not satisfy integer fields; change records are complete. | Type-check before set/dict-key use, parse real UTC timestamps, catch decoding/JSON/resource/depth failures at the full CLI ingestion boundary, and require complete change/artifact identities. | Regression and nested mutation fuzz cover unhashable nested identities/canaries, impossible timestamps, invalid UTF-8, excessive nesting, wrong list types, boolean integers, and omitted fields with no traceback. |
| F11 | Regression count is real and covers policy invariants. | Table-driven suite computes its count from the test table rather than printing a constant. | Focused test output reports the computed count and exits nonzero on any failed case. |
| F12 | Reporting never conflates installation with activation or observation. | Workflow skills and final closeout require the five-field restart contract and independent `built`, `queued`, `sealed`, `activated`, `observed` states. | Closeout report names target processes, grouping, evidence, rollback identity, and each reached state. |
| F13 | Publication starts from and ends at current remote exact head. | Fast-forward before edits; publish only through the canonical helper; verify local HEAD, `origin/main`, `git ls-remote`, and GitHub API readback. | Four exact SHAs agree and worktree is clean. |
| F14 | Parity claims exclude generated bytecode only when explicitly qualified. | Run validation with `python -B`; remove/ignore `__pycache__`; distinguish maintained-source parity from complete filesystem-tree parity. | Compare relative maintained source paths and hashes; separately assert no generated cache under the skill tree. |

## Actual existing Kanban worker profiles in scope

At remediation time, existing route targets were:

- `repo-builder-kimi-k2-7-code`
- `repo-ops-glm-5-1`
- `wg-builder-kimi-k2-7-code`
- `wg-builder-reap32-coder`
- `wg-ops-glm-5-2`
- `research-news-nemotron-3-ultra-fr`

Configured route names whose target profiles do not exist on disk are not claimed as installed. If such a profile is later created, its provisioning workflow must install the two gate skills before it becomes spawnable.
