#!/usr/bin/env python3
"""Fail-closed structural validator for restart-window bundle manifests."""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import sys
from datetime import datetime, timezone
from typing import Any

STATES = {"DRAFT", "READY_NOT_EXECUTED", "EXECUTING", "PASS", "BLOCKED", "ROLLED_BACK"}
IMPACTS = {"restart_free", "reload_only", "restart_required", "host_reboot_required", "unknown"}
HEX64 = re.compile(r"^[0-9a-f]{64}$")

SENSITIVE_KEYS = re.compile(r"(?:password|secret|token|cookie|private[_-]?key)", re.I)
CREDENTIAL_VALUES = (
    re.compile(r"(?:https?|ssh|git|ftp|sftp)://[^/@\s:]+:[^/@\s]+@", re.I),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}", re.I),
    re.compile(r"[?&](?:access_?token|api_?key|secret|password)=[^&\s]+", re.I),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,})\b"),
)
FORBIDDEN_WINDOW_WORDS = re.compile(
    r"(?:git[- ]?(?:merge|rebase|cherry-pick)|(?:pip|npm|pnpm|yarn|uv|apt(?:-get)?|dnf|yum|apk)\s+(?:install|ci|sync)|build|compile|download)",
    re.I,
)
IMMUTABLE_FIELDS = (
    "schema_version", "bundle_id", "bundle_revision", "created_at", "cutoff_at",
    "before", "target", "changes", "services", "aggregate_verification",
    "rollback", "controller", "execution", "acceptance_plan",
)
RESTART_STEPS = [
    "verify-identities", "pause-approved-intake", "drain", "stop-once",
    "require-old-mainpid-zero", "switch", "start-once",
    "verify-runtime-identities", "run-canaries", "restore-intake",
]
RELOAD_STEPS = [
    "verify-identities", "pause-approved-intake", "drain", "reload-once",
    "verify-runtime-identities", "run-canaries", "restore-intake",
]
HOST_REBOOT_STEPS = [
    "verify-identities", "pause-approved-intake", "drain", "host-reboot-once",
    "verify-runtime-identities", "run-canaries", "restore-intake",
]


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def is_int(value: Any) -> bool:
    return type(value) is int


def is_nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def is_utc_timestamp(value: Any) -> bool:
    if not isinstance(value, str) or not value.endswith("Z"):
        return False
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except (ValueError, OverflowError):
        return False
    return parsed.tzinfo == timezone.utc


def has_credential_value(value: str) -> bool:
    return any(pattern.search(value) for pattern in CREDENTIAL_VALUES)


def walk_sensitive(value: Any, path: str = "$") -> tuple[list[str], list[str]]:
    key_hits: list[str] = []
    value_hits: list[str] = []
    if isinstance(value, dict):
        for index, (key, child) in enumerate(value.items()):
            # Never echo an uncontrolled key name: the key itself may be a secret.
            child_path = f"{path}[key#{index}]"
            if SENSITIVE_KEYS.search(str(key)):
                key_hits.append(child_path)
            if isinstance(child, str) and has_credential_value(child):
                value_hits.append(child_path)
            key_children, value_children = walk_sensitive(child, child_path)
            key_hits.extend(key_children)
            value_hits.extend(value_children)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            child_path = f"{path}[{index}]"
            if isinstance(child, str) and has_credential_value(child):
                value_hits.append(child_path)
            key_children, value_children = walk_sensitive(child, child_path)
            key_hits.extend(key_children)
            value_hits.extend(value_children)
    return key_hits, value_hits


def canonical_payload_sha256(data: dict[str, Any]) -> str | None:
    if any(key not in data for key in IMMUTABLE_FIELDS):
        return None
    try:
        payload = {key: data[key] for key in IMMUTABLE_FIELDS}
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    except (TypeError, ValueError, UnicodeError):
        return None
    return hashlib.sha256(raw).hexdigest()


def canonical_object_sha256(value: Any) -> str | None:
    try:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    except (TypeError, ValueError, UnicodeError, RecursionError, MemoryError):
        return None
    return hashlib.sha256(raw).hexdigest()


def validate_evidence_list(value: Any, label: str, errors: list[str], *, required: bool) -> None:
    require(isinstance(value, list), f"{label} must be a list", errors)
    if not isinstance(value, list):
        return
    if required:
        require(bool(value), f"{label} must be non-empty", errors)
    for index, item in enumerate(value):
        item_label = f"{label}[{index}]"
        require(isinstance(item, dict), f"{item_label} must be an object", errors)
        if not isinstance(item, dict):
            continue
        require(is_nonempty_string(item.get("kind")), f"{item_label}.kind is required", errors)
        require(is_nonempty_string(item.get("identity")), f"{item_label}.identity is required", errors)
        digest = item.get("sha256")
        require(isinstance(digest, str) and bool(HEX64.fullmatch(digest)), f"{item_label}.sha256 must be 64 lowercase hex characters", errors)


def validate_artifacts(container: Any, side: str, errors: list[str]) -> dict[str, dict[str, Any]]:
    require(isinstance(container, dict), f"{side} must be an object", errors)
    if isinstance(container, dict):
        require(is_nonempty_string(container.get("generation_identity")), f"{side}.generation_identity is required", errors)
    artifacts = container.get("artifacts") if isinstance(container, dict) else None
    require(isinstance(artifacts, list) and bool(artifacts), f"{side}.artifacts must be a non-empty list", errors)
    result: dict[str, dict[str, Any]] = {}
    if not isinstance(artifacts, list):
        return result
    for index, artifact in enumerate(artifacts):
        label = f"{side}.artifacts[{index}]"
        require(isinstance(artifact, dict), f"{label} must be an object", errors)
        if not isinstance(artifact, dict):
            continue
        name = artifact.get("name")
        require(is_nonempty_string(name), f"{label}.name is required", errors)
        require(is_nonempty_string(artifact.get("kind")), f"{label}.kind is required", errors)
        require(is_nonempty_string(artifact.get("identity")), f"{label}.identity is required", errors)
        digest = artifact.get("sha256")
        require(isinstance(digest, str) and bool(HEX64.fullmatch(digest)), f"{label}.sha256 must be 64 lowercase hex characters", errors)
        if isinstance(name, str) and name.strip():
            require(name not in result, f"duplicate {side} artifact name", errors)
            result[name] = artifact
    return result


def validate(data: Any) -> list[str]:
    errors: list[str] = []
    require(isinstance(data, dict), "root must be an object", errors)
    if not isinstance(data, dict):
        return errors

    require(is_int(data.get("schema_version")) and data.get("schema_version") == 1, "schema_version must equal integer 1", errors)
    bundle_id = data.get("bundle_id")
    require(is_nonempty_string(bundle_id), "bundle_id is required", errors)
    revision = data.get("bundle_revision")
    require(isinstance(revision, int) and not isinstance(revision, bool) and revision > 0, "bundle_revision must be a positive integer", errors)
    state = data.get("bundle_state")
    require(isinstance(state, str), "bundle_state must be a string", errors)
    if isinstance(state, str):
        require(state in STATES, f"bundle_state must be one of {sorted(STATES)}", errors)
    require(is_utc_timestamp(data.get("created_at")), "created_at must be a UTC timestamp", errors)
    require(is_utc_timestamp(data.get("cutoff_at")), "cutoff_at must be a UTC timestamp", errors)

    sensitive_keys, sensitive_values = walk_sensitive(data)
    require(not sensitive_keys, f"secret-bearing key names are forbidden at {', '.join(sensitive_keys)}", errors)
    require(not sensitive_values, f"credential-like value is forbidden at {', '.join(sensitive_values)}", errors)

    before = validate_artifacts(data.get("before"), "before", errors)
    target = validate_artifacts(data.get("target"), "target", errors)
    if before and target:
        require(set(before) == set(target), "before and target artifact names must exactly match", errors)

    changes = data.get("changes")
    require(isinstance(changes, list) and bool(changes), "changes must be a non-empty list", errors)
    impacts: list[str] = []
    if isinstance(changes, list):
        ids: set[str] = set()
        for index, change in enumerate(changes):
            label = f"changes[{index}]"
            require(isinstance(change, dict), f"{label} must be an object", errors)
            if not isinstance(change, dict):
                continue
            cid = change.get("id")
            require(is_nonempty_string(cid), f"{label}.id is required", errors)
            if isinstance(cid, str) and cid.strip():
                require(cid not in ids, "duplicate change id", errors)
                ids.add(cid)
            require(is_nonempty_string(change.get("component")), f"{label}.component is required", errors)
            require(is_nonempty_string(change.get("repository")), f"{label}.repository is required", errors)
            impact = change.get("restart_impact")
            require(isinstance(impact, str), f"{label}.restart_impact must be a string", errors)
            if isinstance(impact, str):
                require(impact in IMPACTS, f"{label}.restart_impact is invalid", errors)
                if impact in IMPACTS:
                    impacts.append(impact)
            artifact = change.get("artifact")
            require(isinstance(artifact, str) and artifact in target, f"{label}.artifact must name a target artifact", errors)
            if isinstance(artifact, str) and artifact in target:
                require(change.get("candidate_identity") == target[artifact].get("identity"), f"{label}.candidate_identity must match target artifact identity", errors)
            classification = change.get("classification_evidence")
            require(
                isinstance(classification, list) and bool(classification)
                and all(is_nonempty_string(item) for item in classification),
                f"{label}.classification_evidence must be a non-empty string list", errors,
            )
            grouping = change.get("activation_grouping")
            require(is_nonempty_string(grouping), f"{label}.activation_grouping is required", errors)
            if is_nonempty_string(grouping) and is_nonempty_string(bundle_id):
                require(grouping in {"standalone", "deferred", f"bundle:{bundle_id}"}, f"{label}.activation_grouping is invalid", errors)
                if isinstance(impact, str) and impact in {"restart_required", "unknown", "host_reboot_required"}:
                    require(grouping == f"bundle:{bundle_id}", f"{label}.activation_grouping must bind restart/reboot work to this bundle", errors)
            compatibility = change.get("compatibility")
            require(isinstance(compatibility, list), f"{label}.compatibility must be a list", errors)
            if isinstance(compatibility, list):
                require(all(is_nonempty_string(item) for item in compatibility), f"{label}.compatibility entries must be non-empty strings", errors)
            if state != "DRAFT":
                require(change.get("tests") == "PASS", f"{label}.tests must be PASS when sealed", errors)
                require(change.get("review") == "PASS", f"{label}.review must be PASS when sealed", errors)

    require(any(impact in {"reload_only", "restart_required", "host_reboot_required", "unknown"} for impact in impacts), "bundle must contain a reload/restart/reboot/unknown change", errors)

    services = data.get("services")
    require(isinstance(services, list) and bool(services), "services must be a non-empty list", errors)
    if isinstance(services, list):
        for index, service in enumerate(services):
            require(is_nonempty_string(service), f"services[{index}] must be a non-empty string", errors)
        strings = [service for service in services if isinstance(service, str)]
        require(len(strings) == len(set(strings)), "services must be unique", errors)

    acceptance = data.get("acceptance_plan")
    require(isinstance(acceptance, dict), "acceptance_plan is required", errors)
    required_canaries: list[str] | None = None
    minimum_observation: int | None = None
    if isinstance(acceptance, dict):
        minimum_value = acceptance.get("minimum_observation_seconds")
        require(is_int(minimum_value) and minimum_value > 0, "acceptance_plan.minimum_observation_seconds must be a positive integer", errors)
        if type(minimum_value) is int and minimum_value > 0:
            minimum_observation = minimum_value
        canary_value = acceptance.get("required_canaries")
        require(
            isinstance(canary_value, list) and bool(canary_value)
            and all(is_nonempty_string(item) for item in canary_value),
            "acceptance_plan.required_canaries must be a non-empty string list", errors,
        )
        if isinstance(canary_value, list) and all(isinstance(item, str) for item in canary_value):
            required_canaries = canary_value
            require(len(required_canaries) == len(set(required_canaries)), "acceptance_plan.required_canaries must be unique", errors)

    sealed_state = state in STATES - {"DRAFT"} if isinstance(state, str) else False
    aggregate = data.get("aggregate_verification")
    require(isinstance(aggregate, dict), "aggregate_verification is required", errors)
    if isinstance(aggregate, dict):
        if sealed_state:
            require(aggregate.get("status") == "PASS", "aggregate_verification.status must be PASS when sealed", errors)
        validate_evidence_list(aggregate.get("evidence"), "aggregate_verification.evidence", errors, required=sealed_state)

    rollback = data.get("rollback")
    require(isinstance(rollback, dict), "rollback is required", errors)
    if isinstance(rollback, dict):
        require(rollback.get("status") == "AVAILABLE", "rollback.status must be AVAILABLE", errors)
        require(is_nonempty_string(rollback.get("generation_identity")), "rollback.generation_identity is required", errors)
        if before and is_nonempty_string(rollback.get("generation_identity")):
            before_generation = data.get("before", {}).get("generation_identity") if isinstance(data.get("before"), dict) else None
            require(rollback.get("generation_identity") == before_generation, "rollback.generation_identity must resolve to the before generation", errors)
        rollback_digest = rollback.get("manifest_sha256")
        require(isinstance(rollback_digest, str) and bool(HEX64.fullmatch(rollback_digest)), "rollback.manifest_sha256 must be 64 lowercase hex characters", errors)
        before_digest = canonical_object_sha256(data.get("before"))
        if isinstance(rollback_digest, str) and HEX64.fullmatch(rollback_digest) and before_digest is not None:
            require(rollback_digest == before_digest, "rollback.manifest_sha256 must match the complete before manifest", errors)
        rollback_artifacts = rollback.get("artifacts")
        require(isinstance(rollback_artifacts, list), "rollback.artifacts must be a list", errors)
        if isinstance(rollback_artifacts, list) and before:
            valid_items = all(is_nonempty_string(item) for item in rollback_artifacts)
            require(valid_items and set(rollback_artifacts) == set(before), "rollback.artifacts must exactly match before artifacts", errors)
        verification = rollback.get("verification")
        require(isinstance(verification, dict), "rollback.verification is required", errors)
        if isinstance(verification, dict):
            if sealed_state:
                require(verification.get("status") == "PASS", "rollback.verification.status must be PASS when sealed", errors)
            validate_evidence_list(verification.get("evidence"), "rollback.verification.evidence", errors, required=sealed_state)
            if sealed_state and isinstance(verification.get("evidence"), list):
                restore_identity = rollback.get("generation_identity")
                require(
                    any(isinstance(item, dict) and item.get("kind") == "restore-smoke" and item.get("identity") == restore_identity for item in verification["evidence"]),
                    "rollback.verification.evidence must include restore-smoke bound to rollback generation_identity", errors,
                )

    controller = data.get("controller")
    require(isinstance(controller, dict), "controller is required", errors)
    if isinstance(controller, dict):
        require(controller.get("external") is True, "controller.external must be true", errors)
        require(is_nonempty_string(controller.get("identity")), "controller.identity is required", errors)
        controller_digest = controller.get("sha256")
        require(isinstance(controller_digest, str) and bool(HEX64.fullmatch(controller_digest)), "controller.sha256 must be 64 lowercase hex characters", errors)

    execution = data.get("execution")
    require(isinstance(execution, dict), "execution is required", errors)
    mode: str | None = None
    if isinstance(execution, dict):
        require(execution.get("external_supervisor") is True, "execution.external_supervisor must be true", errors)
        require(is_nonempty_string(execution.get("execution_identity")), "execution.execution_identity is required", errors)
        mode_value = execution.get("activation_mode")
        require(isinstance(mode_value, str), "execution.activation_mode must be a string", errors)
        if isinstance(mode_value, str):
            mode = mode_value
            require(mode in {"reload", "restart", "host_reboot"}, "execution.activation_mode is invalid", errors)
        drain = execution.get("max_drain_seconds")
        require(isinstance(drain, int) and not isinstance(drain, bool) and drain > 0, "execution.max_drain_seconds must be a positive integer", errors)
        result_path = execution.get("result_path")
        require(isinstance(result_path, str) and bool(result_path) and pathlib.PurePath(result_path).is_absolute(), "execution.result_path must be absolute", errors)
        steps = execution.get("window_steps")
        require(isinstance(steps, list) and bool(steps), "execution.window_steps must be non-empty", errors)
        if isinstance(steps, list):
            for index, step in enumerate(steps):
                require(is_nonempty_string(step), f"execution.window_steps[{index}] must be a non-empty string", errors)
            forbidden_paths = [f"execution.window_steps[{index}]" for index, step in enumerate(steps) if isinstance(step, str) and FORBIDDEN_WINDOW_WORDS.search(step)]
            require(not forbidden_paths, f"forbidden preparation appears at {', '.join(forbidden_paths)}", errors)
            expected = {"reload": RELOAD_STEPS, "restart": RESTART_STEPS, "host_reboot": HOST_REBOOT_STEPS}.get(mode) if mode is not None else None
            if expected is not None:
                require(steps == expected, f"execution.window_steps must equal the exact ordered {mode} lifecycle", errors)

    has_host = "host_reboot_required" in impacts
    has_restart = any(impact in {"restart_required", "unknown"} for impact in impacts)
    has_reload = "reload_only" in impacts
    if has_host:
        require(all(impact in {"host_reboot_required", "restart_free"} for impact in impacts), "host reboot work must be a separate failure-domain bundle", errors)
        require(mode == "host_reboot", "host reboot changes require activation_mode host_reboot", errors)
    elif has_restart:
        require(mode == "restart", "restart_required or unknown changes require activation_mode restart", errors)
    elif has_reload:
        require(mode == "reload", "reload_only changes require activation_mode reload", errors)

    payload_digest = canonical_payload_sha256(data)
    seal = data.get("seal")
    require(isinstance(seal, dict), "seal is required", errors)
    if isinstance(seal, dict):
        if sealed_state:
            require(seal.get("status") == "SEALED", "seal.status must be SEALED", errors)
            digest = seal.get("payload_sha256")
            require(isinstance(digest, str) and bool(HEX64.fullmatch(digest)), "seal.payload_sha256 must be 64 lowercase hex characters", errors)
            if payload_digest is not None and isinstance(digest, str) and HEX64.fullmatch(digest):
                require(digest == payload_digest, "sealed payload digest mismatch", errors)
            require(is_utc_timestamp(seal.get("sealed_at")), "seal.sealed_at must be a UTC timestamp", errors)
            require(is_nonempty_string(seal.get("sealed_by")), "seal.sealed_by is required", errors)
        else:
            require(seal.get("status") == "UNSEALED", "draft seal.status must be UNSEALED", errors)

    auth = data.get("authorization")
    require(isinstance(auth, dict), "authorization is required", errors)
    if isinstance(auth, dict):
        bool_fields = ("deployment_approved", "intake_pause_approved", "reload_approved", "restart_approved", "host_reboot_approved")
        for field in bool_fields:
            require(type(auth.get(field)) is bool, f"authorization.{field} must be boolean", errors)
        if sealed_state:
            require(auth.get("deployment_approved") is True, "deployment approval is required for sealed execution", errors)
            require(auth.get("intake_pause_approved") is True, "intake pause approval is required for sealed execution", errors)
            if mode == "reload":
                require(auth.get("reload_approved") is True, "reload approval is required for reload execution", errors)
                require(auth.get("restart_approved") is False, "restart approval must be false for reload-only execution", errors)
            elif mode == "restart":
                require(auth.get("restart_approved") is True, "restart approval is required for restart execution", errors)
            elif mode == "host_reboot":
                require(auth.get("host_reboot_approved") is True, "host reboot changes require explicit approval", errors)
            require(is_nonempty_string(auth.get("approved_by")), "authorization.approved_by is required", errors)
            require(is_utc_timestamp(auth.get("approved_at")), "authorization.approved_at must be a UTC timestamp", errors)
            require(auth.get("approved_bundle_id") == bundle_id, "authorization.approved_bundle_id must match bundle_id", errors)
            require(is_int(auth.get("approved_revision")) and auth.get("approved_revision") == revision, "authorization.approved_revision must match bundle_revision", errors)
            require(payload_digest is not None and auth.get("approved_payload_sha256") == payload_digest, "authorization.approved_payload_sha256 must bind the sealed payload", errors)
            controller_sha = controller.get("sha256") if isinstance(controller, dict) else None
            require(auth.get("approved_controller_sha256") == controller_sha, "authorization.approved_controller_sha256 must bind the controller", errors)
            rollback_sha = rollback.get("manifest_sha256") if isinstance(rollback, dict) else None
            require(auth.get("approved_rollback_manifest_sha256") == rollback_sha, "authorization.approved_rollback_manifest_sha256 must bind rollback", errors)

    execution_result = data.get("execution_result")
    require(isinstance(execution_result, dict), "execution_result is required", errors)
    if state == "PASS" and isinstance(execution_result, dict):
        require(execution_result.get("status") == "PASS", "execution_result.status must be PASS", errors)
        require(is_int(execution_result.get("activation_count")) and execution_result.get("activation_count") == 1, "execution_result.activation_count must equal 1", errors)
        expected_shutdown = "NOT_APPLICABLE" if mode == "reload" else "PASS"
        require(execution_result.get("shutdown_status") == expected_shutdown, f"execution_result.shutdown_status must be {expected_shutdown}", errors)
        require(execution_result.get("old_main_pids_zero") == expected_shutdown, f"execution_result.old_main_pids_zero must be {expected_shutdown}", errors)
        runtime = execution_result.get("runtime_artifacts")
        require(isinstance(runtime, list), "execution_result.runtime_artifacts must be a list", errors)
        runtime_map: dict[str, str] = {}
        if isinstance(runtime, list):
            for index, item in enumerate(runtime):
                label = f"execution_result.runtime_artifacts[{index}]"
                require(isinstance(item, dict), f"{label} must be an object", errors)
                if isinstance(item, dict):
                    name = item.get("name")
                    digest = item.get("sha256")
                    require(is_nonempty_string(name), f"{label}.name is required", errors)
                    require(isinstance(digest, str) and bool(HEX64.fullmatch(digest)), f"{label}.sha256 must be 64 lowercase hex characters", errors)
                    if isinstance(name, str) and isinstance(digest, str):
                        require(name not in runtime_map, "execution_result.runtime_artifacts names must be unique", errors)
                        runtime_map[name] = digest
        expected_runtime = {name: item.get("sha256") for name, item in target.items()}
        require(runtime_map == expected_runtime, "execution_result.runtime_artifacts must exactly match target artifacts", errors)
        validate_evidence_list(execution_result.get("evidence"), "execution_result.evidence", errors, required=True)
        require(execution_result.get("bundle_id") == bundle_id, "execution_result.bundle_id must match bundle_id", errors)
        require(execution_result.get("bundle_revision") == revision, "execution_result.bundle_revision must match bundle_revision", errors)
        controller_sha = controller.get("sha256") if isinstance(controller, dict) else None
        require(execution_result.get("controller_sha256") == controller_sha, "execution_result.controller_sha256 must match controller", errors)
        execution_identity = execution.get("execution_identity") if isinstance(execution, dict) else None
        require(execution_result.get("execution_identity") == execution_identity, "execution_result.execution_identity must match execution", errors)
        target_generation = data.get("target", {}).get("generation_identity") if isinstance(data.get("target"), dict) else None
        require(execution_result.get("target_generation_identity") == target_generation, "execution_result.target_generation_identity must match target generation", errors)
        evidence_items = execution_result.get("evidence")
        if isinstance(evidence_items, list):
            require(
                any(isinstance(item, dict) and item.get("kind") == "activation-result" and item.get("identity") == execution_identity for item in evidence_items),
                "execution_result.evidence must include activation-result bound to execution_identity", errors,
            )
        require(execution_result.get("rollback_disposition") == "NOT_NEEDED", "execution_result.rollback_disposition must be NOT_NEEDED for PASS", errors)
    elif isinstance(execution_result, dict):
        expected_result = {
            "DRAFT": ("PENDING", 0, "PENDING"),
            "READY_NOT_EXECUTED": ("PENDING", 0, "PENDING"),
            "EXECUTING": ("EXECUTING", 0, "PENDING"),
            "BLOCKED": ("BLOCKED", 0, "PENDING"),
            "ROLLED_BACK": ("ROLLED_BACK", 1, "PERFORMED"),
        }.get(state) if isinstance(state, str) else None
        if expected_result is not None:
            status_value, count_value, rollback_value = expected_result
            require(execution_result.get("status") == status_value, f"execution_result.status must be {status_value} for {state}", errors)
            require(is_int(execution_result.get("activation_count")) and execution_result.get("activation_count") == count_value, f"execution_result.activation_count must equal {count_value} for {state}", errors)
            require(execution_result.get("rollback_disposition") == rollback_value, f"execution_result.rollback_disposition must be {rollback_value} for {state}", errors)

    observation = data.get("observation")
    require(isinstance(observation, dict), "observation is required", errors)
    if state == "PASS" and isinstance(observation, dict):
        require(observation.get("status") == "PASS", "observation.status must be PASS", errors)
        observed = observation.get("observed_seconds")
        observed_is_valid = type(observed) is int and observed >= 0
        require(observed_is_valid, "observation.observed_seconds must be a non-negative integer", errors)
        if observed_is_valid and minimum_observation is not None:
            assert isinstance(observed, int)
            require(observed >= minimum_observation, "observation.observed_seconds must meet acceptance_plan minimum", errors)
        results = observation.get("canary_results")
        require(isinstance(results, list), "observation.canary_results must be a list", errors)
        names: list[str] = []
        if isinstance(results, list):
            for index, result in enumerate(results):
                label = f"observation.canary_results[{index}]"
                require(isinstance(result, dict), f"{label} must be an object", errors)
                if not isinstance(result, dict):
                    continue
                name = result.get("name")
                require(is_nonempty_string(name), f"{label}.name is required", errors)
                if isinstance(name, str):
                    names.append(name)
                require(result.get("status") == "PASS", f"{label}.status must be PASS", errors)
                validate_evidence_list(result.get("evidence"), f"{label}.evidence", errors, required=True)
        if required_canaries is not None:
            require(len(names) == len(set(names)) and set(names) == set(required_canaries), "observation.canary_results must exactly match required_canaries", errors)
        validate_evidence_list(observation.get("evidence"), "observation.evidence", errors, required=True)
    elif isinstance(observation, dict):
        expected_observation = "PENDING" if isinstance(state, str) and state in {"DRAFT", "READY_NOT_EXECUTED", "EXECUTING"} else "BLOCKED"
        require(observation.get("status") == expected_observation, f"observation.status must be {expected_observation} for {state}", errors)

    return errors


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(f"usage: {argv[0]} MANIFEST.json", file=sys.stderr)
        return 64
    path = pathlib.Path(argv[1])
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError, RecursionError, MemoryError):
        print("BLOCKED manifest_read")
        return 2
    try:
        errors = validate(data)
    except (TypeError, ValueError, UnicodeError, RecursionError, MemoryError):
        print("BLOCKED internal_validation")
        return 2
    if errors:
        print("BLOCKED")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"VALID bundle_id={data['bundle_id']} state={data['bundle_state']} changes={len(data['changes'])} services={len(data['services'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
