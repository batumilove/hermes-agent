#!/usr/bin/env python3
"""Regression tests for validate_bundle.py; stdlib only."""
from __future__ import annotations

import copy
import contextlib
import hashlib
import importlib.util
import io
import json
import pathlib
import tempfile
from typing import Any, Callable

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("validate_bundle", ROOT / "scripts" / "validate_bundle.py")
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

IMMUTABLE_FIELDS = (
    "schema_version", "bundle_id", "bundle_revision", "created_at", "cutoff_at",
    "before", "target", "changes", "services", "aggregate_verification",
    "rollback", "controller", "execution", "acceptance_plan",
)
HEX_A = "a" * 64
HEX_B = "b" * 64
HEX_C = "c" * 64
HEX_D = "d" * 64


def canonical_sha(data: dict[str, Any]) -> str:
    payload = {key: data[key] for key in IMMUTABLE_FIELDS}
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def canonical_object_sha(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def evidence(kind: str, identity: str, digest: str = HEX_C) -> dict[str, str]:
    return {"kind": kind, "identity": identity, "sha256": digest}


def draft_manifest() -> dict[str, Any]:
    data = {
        "schema_version": 1,
        "bundle_id": "example-service-20260101-r1",
        "bundle_revision": 1,
        "bundle_state": "DRAFT",
        "created_at": "2026-01-01T00:00:00Z",
        "cutoff_at": "2026-01-01T12:00:00Z",
        "before": {"generation_identity": "generation-0", "artifacts": [{
            "name": "application", "kind": "git-tree",
            "identity": "0" * 40, "sha256": "0" * 64,
        }]},
        "target": {"generation_identity": "generation-1", "artifacts": [{
            "name": "application", "kind": "git-tree",
            "identity": "1" * 40, "sha256": "1" * 64,
        }]},
        "changes": [{
            "id": "change-1", "component": "application", "repository": "example/application",
            "restart_impact": "restart_required", "artifact": "application",
            "candidate_identity": "1" * 40,
            "classification_evidence": ["service reads code only at process start"],
            "activation_grouping": "bundle:example-service-20260101-r1",
            "tests": "PENDING", "review": "PENDING", "compatibility": [],
        }],
        "services": ["example.service"],
        "aggregate_verification": {"status": "PENDING", "evidence": []},
        "rollback": {
            "status": "AVAILABLE", "generation_identity": "generation-0",
            "manifest_sha256": None, "artifacts": ["application"],
            "verification": {"status": "PENDING", "evidence": []},
        },
        "controller": {
            "external": True, "identity": "/opt/restart-controller-v1.py",
            "sha256": HEX_B,
        },
        "authorization": {
            "deployment_approved": False, "intake_pause_approved": False,
            "reload_approved": False, "restart_approved": False,
            "host_reboot_approved": False,
            "approved_by": None, "approved_at": None, "approved_bundle_id": None,
            "approved_revision": None, "approved_payload_sha256": None,
            "approved_controller_sha256": None,
            "approved_rollback_manifest_sha256": None,
        },
        "execution": {
            "external_supervisor": True, "execution_identity": "window-exec-1",
            "activation_mode": "restart",
            "max_drain_seconds": 180,
            "result_path": "/absolute/path/to/result.json",
            "window_steps": [
                "verify-identities", "pause-approved-intake", "drain",
                "stop-once", "require-old-mainpid-zero", "switch", "start-once",
                "verify-runtime-identities", "run-canaries", "restore-intake",
            ],
        },
        "acceptance_plan": {
            "minimum_observation_seconds": 1800,
            "required_canaries": ["direct-smoke", "natural-cycle"],
        },
        "seal": {
            "status": "UNSEALED", "payload_sha256": None,
            "sealed_at": None, "sealed_by": None,
        },
        "execution_result": {
            "status": "PENDING", "activation_count": 0,
            "shutdown_status": "PENDING", "old_main_pids_zero": "PENDING",
            "runtime_artifacts": [], "evidence": [],
            "rollback_disposition": "PENDING",
        },
        "observation": {
            "status": "PENDING", "observed_seconds": 0,
            "canary_results": [], "evidence": [],
        },
    }
    data["rollback"]["manifest_sha256"] = canonical_object_sha(data["before"])
    return data


def sealed_manifest(state: str = "READY_NOT_EXECUTED") -> dict[str, Any]:
    data = draft_manifest()
    data["bundle_state"] = state
    data["changes"][0]["tests"] = "PASS"
    data["changes"][0]["review"] = "PASS"
    data["aggregate_verification"] = {
        "status": "PASS",
        "evidence": [evidence("test-log", "aggregate-tests")],
    }
    data["rollback"]["verification"] = {
        "status": "PASS",
        "evidence": [evidence("restore-smoke", data["rollback"]["generation_identity"])],
    }
    digest = canonical_sha(data)
    data["seal"] = {
        "status": "SEALED", "payload_sha256": digest,
        "sealed_at": "2026-01-01T10:00:00Z", "sealed_by": "release-controller",
    }
    data["authorization"].update({
        "deployment_approved": True,
        "intake_pause_approved": True,
        "reload_approved": False,
        "restart_approved": True,
        "approved_by": "operator:aleman",
        "approved_at": "2026-01-01T11:00:00Z",
        "approved_bundle_id": data["bundle_id"],
        "approved_revision": data["bundle_revision"],
        "approved_payload_sha256": digest,
        "approved_controller_sha256": data["controller"]["sha256"],
        "approved_rollback_manifest_sha256": data["rollback"]["manifest_sha256"],
    })
    if state == "PASS":
        data["execution_result"] = {
            "status": "PASS", "activation_count": 1,
            "shutdown_status": "PASS", "old_main_pids_zero": "PASS",
            "runtime_artifacts": [{"name": "application", "sha256": "1" * 64}],
            "bundle_id": data["bundle_id"], "bundle_revision": data["bundle_revision"],
            "controller_sha256": data["controller"]["sha256"],
            "execution_identity": data["execution"]["execution_identity"],
            "target_generation_identity": data["target"]["generation_identity"],
            "evidence": [evidence("activation-result", data["execution"]["execution_identity"])],
            "rollback_disposition": "NOT_NEEDED",
        }
        data["observation"] = {
            "status": "PASS", "observed_seconds": 1800,
            "canary_results": [
                {"name": "direct-smoke", "status": "PASS", "evidence": [evidence("canary", "direct")]},
                {"name": "natural-cycle", "status": "PASS", "evidence": [evidence("canary", "natural")]},
            ],
            "evidence": [evidence("observation-log", "acceptance-window")],
        }
    return data


def expect_valid(data: Any) -> None:
    errors = MODULE.validate(data)
    assert errors == [], errors


def expect_error(data: Any, needle: str) -> list[str]:
    try:
        errors = MODULE.validate(data)
    except Exception as exc:  # validator contract is deterministic BLOCKED, never a crash
        raise AssertionError(f"validate raised {type(exc).__name__}: {exc}") from exc
    assert any(needle in error for error in errors), errors
    return errors


def mutate(data: dict[str, Any], fn: Callable[[dict[str, Any]], Any]) -> dict[str, Any]:
    result = copy.deepcopy(data)
    fn(result)
    return result


def _make_reload(data: dict[str, Any]) -> None:
    data["changes"][0]["restart_impact"] = "reload_only"
    data["authorization"]["reload_approved"] = True
    data["authorization"]["restart_approved"] = False
    data["execution"].update({
        "activation_mode": "reload",
        "window_steps": [
            "verify-identities", "pause-approved-intake", "drain", "reload-once",
            "verify-runtime-identities", "run-canaries", "restore-intake",
        ],
    })
    _rebind(data)


def run_tests() -> list[tuple[str, Callable[[], Any]]]:
    draft = draft_manifest()
    sealed = sealed_manifest()
    passed = sealed_manifest("PASS")
    secret = "https://user:synthetic-password@example.invalid/pkg"

    return [
        ("valid draft", lambda: expect_valid(draft)),
        ("valid sealed", lambda: expect_valid(sealed)),
        ("valid pass", lambda: expect_valid(passed)),
        ("seal digest syntax", lambda: expect_error(mutate(sealed, lambda d: d["seal"].update(payload_sha256="abc")), "seal.payload_sha256")),
        ("seal payload drift", lambda: expect_error(mutate(sealed, lambda d: d["target"]["artifacts"][0].update(identity="mutable-main", sha256=HEX_A)), "sealed payload digest mismatch")),
        ("acceptance plan sealed", lambda: expect_error(mutate(sealed, lambda d: d["acceptance_plan"].update(minimum_observation_seconds=1)), "sealed payload digest mismatch")),
        ("approval payload binding", lambda: expect_error(mutate(sealed, lambda d: d["authorization"].update(approved_payload_sha256=HEX_A)), "approved_payload_sha256")),
        ("approval revision binding", lambda: expect_error(mutate(sealed, lambda d: d["authorization"].update(approved_revision=2)), "approved_revision")),
        ("approval controller binding", lambda: expect_error(mutate(sealed, lambda d: d["authorization"].update(approved_controller_sha256=HEX_A)), "approved_controller_sha256")),
        ("approval rollback binding", lambda: expect_error(mutate(sealed, lambda d: d["authorization"].update(approved_rollback_manifest_sha256=HEX_A)), "approved_rollback_manifest_sha256")),
        ("evidence object shape", lambda: expect_error(mutate(sealed, lambda d: d["aggregate_verification"].update(evidence=[None])), "aggregate_verification.evidence[0]")),
        ("evidence digest strict", lambda: expect_error(mutate(sealed, lambda d: d["aggregate_verification"].update(evidence=[{"kind": "log", "identity": "x", "sha256": "abc"}])), "aggregate_verification.evidence[0].sha256")),
        ("rollback references before generation", lambda: expect_error(mutate(sealed, lambda d: d["rollback"].update(artifacts=["not-in-before"])), "rollback.artifacts must exactly match before artifacts")),
        ("rollback generation identity", lambda: expect_error(mutate(sealed, lambda d: d["rollback"].update(generation_identity="mutable-main")), "rollback.generation_identity")),
        ("rollback verification", lambda: expect_error(mutate(sealed, lambda d: d["rollback"]["verification"].update(status="PENDING", evidence=[])), "rollback.verification.status")),
        ("rollback manifest complete", lambda: expect_error(mutate(sealed, lambda d: d["rollback"].update(manifest_sha256=HEX_A)), "complete before manifest")),
        ("rollback restore-smoke semantic", lambda: expect_error(mutate(sealed, lambda d: (d["rollback"]["verification"].update(evidence=[evidence("unrelated-log", "no-restore")]), _rebind(d))), "restore-smoke bound")),
        ("intake authorization", lambda: expect_error(mutate(sealed_manifest("EXECUTING"), lambda d: d["authorization"].update(intake_pause_approved=False)), "intake pause approval")),
        ("null window step", lambda: expect_error(mutate(sealed, lambda d: d["execution"].update(window_steps=[None])), "execution.window_steps[0]")),
        ("package install in window", lambda: expect_error(mutate(sealed, lambda d: d["execution"]["window_steps"].insert(1, "apt-get install nginx")), "forbidden preparation")),
        ("ordered lifecycle", lambda: expect_error(mutate(sealed, lambda d: d["execution"]["window_steps"].reverse()), "exact ordered restart lifecycle")),
        ("multiple restart commands", lambda: expect_error(mutate(sealed, lambda d: d["execution"]["window_steps"].extend(["systemctl restart a", "systemctl restart b"])), "exact ordered restart lifecycle")),
        ("controller identity", lambda: expect_error(mutate(sealed, lambda d: d["controller"].update(identity="")), "controller.identity")),
        ("pass requires execution result", lambda: expect_error(mutate(passed, lambda d: d.pop("execution_result")), "execution_result is required")),
        ("pass activation once", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(activation_count=2)), "activation_count must equal 1")),
        ("pass shutdown evidence", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(shutdown_status="PENDING")), "shutdown_status must be PASS")),
        ("pass runtime identity", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(runtime_artifacts=[])), "runtime_artifacts must exactly match target artifacts")),
        ("pass duplicate runtime identity", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(runtime_artifacts=[{"name": "application", "sha256": HEX_A}, {"name": "application", "sha256": "1" * 64}])), "names must be unique")),
        ("pass execution receipt semantic", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(evidence=[evidence("unrelated-log", "window-exec-1")])), "activation-result bound")),
        ("pass execution receipt binding", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(controller_sha256=HEX_A)), "controller_sha256")),
        ("pass observation present", lambda: expect_error(mutate(passed, lambda d: d.pop("observation")), "observation is required")),
        ("pass observed duration", lambda: expect_error(mutate(passed, lambda d: d["observation"].update(observed_seconds=1799)), "observed_seconds")),
        ("pass all canaries", lambda: expect_error(mutate(passed, lambda d: d["observation"].update(canary_results=d["observation"]["canary_results"][:1])), "canary_results must exactly match required_canaries")),
        ("pass rollback disposition", lambda: expect_error(mutate(passed, lambda d: d["execution_result"].update(rollback_disposition="PENDING")), "rollback_disposition")),
        ("ready rejects completed result", lambda: expect_error(mutate(sealed, lambda d: d["execution_result"].update(status="PASS", activation_count=1)), "status must be PENDING")),
        ("rolled back rejects pending result", lambda: expect_error(mutate(sealed_manifest("ROLLED_BACK"), lambda d: None), "status must be ROLLED_BACK")),
        ("reload forbids replacement", lambda: expect_error(mutate(sealed, lambda d: (d["changes"][0].update(restart_impact="reload_only"), d["execution"].update(activation_mode="reload"))), "exact ordered reload lifecycle")),
        ("reload valid lifecycle", lambda: expect_valid(mutate(sealed, _make_reload))),
        ("credential value rejected", lambda: expect_error(mutate(sealed, lambda d: d["target"]["artifacts"][0].update(identity=secret)), "credential-like value is forbidden")),
        ("ssh credential value rejected", lambda: expect_error(mutate(sealed, lambda d: d["target"]["artifacts"][0].update(identity="ssh://user:synthetic-password@example.invalid/repo")), "credential-like value is forbidden")),
        ("credential not echoed", lambda: _assert_secret_redacted(mutate(sealed, lambda d: d["execution"]["window_steps"].append("pip install " + secret)), secret)),
        ("credential-shaped duplicate id not echoed", lambda: _assert_duplicate_redacted(sealed, "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ123456")),
        ("credential-shaped key not echoed", lambda: _assert_key_redacted(sealed, "password-DO-NOT-ECHO")),
        ("bool schema rejected", lambda: expect_error(mutate(draft, lambda d: d.update(schema_version=True)), "schema_version must equal integer 1")),
        ("bool drain rejected", lambda: expect_error(mutate(draft, lambda d: d["execution"].update(max_drain_seconds=True)), "max_drain_seconds must be a positive integer")),
        ("unhashable state deterministic", lambda: expect_error(mutate(draft, lambda d: d.update(bundle_state=[])), "bundle_state must be a string")),
        ("unhashable impact deterministic", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].update(restart_impact={})), "restart_impact must be a string")),
        ("unhashable before identity deterministic", lambda: expect_error(mutate(draft, lambda d: d["before"]["artifacts"][0].update(identity=[])), "identity is required")),
        ("unhashable required canary deterministic", lambda: expect_error(mutate(draft, lambda d: d["acceptance_plan"].update(required_canaries=[[]])), "required_canaries")),
        ("changes wrong type deterministic", lambda: expect_error(mutate(draft, lambda d: d.update(changes=1)), "changes must be a non-empty list")),
        ("services nested list deterministic", lambda: expect_error(mutate(draft, lambda d: d.update(services=[[]])), "services[0] must be a non-empty string")),
        ("component required", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].pop("component")), "component is required")),
        ("candidate identity bound", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].update(candidate_identity="mutable-main")), "candidate_identity must match target artifact identity")),
        ("compatibility required", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].pop("compatibility")), "compatibility must be a list")),
        ("classification evidence required", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].update(classification_evidence=[])), "classification_evidence must be a non-empty string list")),
        ("activation grouping required", lambda: expect_error(mutate(draft, lambda d: d["changes"][0].pop("activation_grouping")), "activation_grouping is required")),
        ("impossible timestamp rejected", lambda: expect_error(mutate(draft, lambda d: d.update(created_at="2026-99-99T99:99:99Z")), "created_at")),
        ("invalid utf8 CLI blocked", _assert_invalid_utf8_blocked),
        ("excessive nesting CLI blocked", _assert_nesting_blocked),
    ]


def _rebind(data: dict[str, Any]) -> None:
    digest = canonical_sha(data)
    data["seal"]["payload_sha256"] = digest
    data["authorization"]["approved_payload_sha256"] = digest


def _assert_secret_redacted(data: dict[str, Any], secret: str) -> None:
    errors = expect_error(data, "forbidden preparation")
    assert secret not in "\n".join(errors), errors


def _assert_duplicate_redacted(data: dict[str, Any], secret: str) -> None:
    candidate = copy.deepcopy(data)
    candidate["changes"].append(copy.deepcopy(candidate["changes"][0]))
    candidate["changes"][0]["id"] = secret
    candidate["changes"][1]["id"] = secret
    errors = expect_error(candidate, "duplicate change id")
    assert secret not in "\n".join(errors), errors


def _assert_key_redacted(data: dict[str, Any], secret: str) -> None:
    candidate = copy.deepcopy(data)
    candidate[secret] = "synthetic"
    errors = expect_error(candidate, "secret-bearing key names")
    assert secret not in "\n".join(errors), errors


def _run_main_with_bytes(raw: bytes) -> tuple[int, str]:
    with tempfile.TemporaryDirectory() as directory:
        path = pathlib.Path(directory) / "manifest.json"
        path.write_bytes(raw)
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            status = MODULE.main(["validate_bundle.py", str(path)])
        return status, output.getvalue()


def _assert_invalid_utf8_blocked() -> None:
    status, output = _run_main_with_bytes(b"{\xff}")
    assert status == 2 and output == "BLOCKED manifest_read\n", (status, output)


def _assert_nesting_blocked() -> None:
    status, output = _run_main_with_bytes(("[" * 2000 + "0" + "]" * 2000).encode())
    assert status == 2 and output == "BLOCKED manifest_read\n", (status, output)


def main() -> None:
    tests = run_tests()
    failures: list[str] = []
    for name, test in tests:
        try:
            test()
        except Exception as exc:
            failures.append(f"{name}: {type(exc).__name__}: {exc}")
    if failures:
        for failure in failures:
            print(f"FAIL {failure}")
        raise SystemExit(1)

    with tempfile.TemporaryDirectory() as directory:
        path = pathlib.Path(directory) / "sealed.json"
        path.write_text(json.dumps(sealed_manifest()))
        assert MODULE.main(["validate_bundle.py", str(path)]) == 0

    print(f"PASS tests={len(tests)}")


if __name__ == "__main__":
    main()
