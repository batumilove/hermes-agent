---
name: kanban-worker
description: Pitfalls, examples, and edge cases for Hermes Kanban workers. The lifecycle is auto-injected as KANBAN_GUIDANCE; maintained dispatchers also force-load this skill and restart-window-bundling, failing closed if either is unavailable.
version: 2.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kanban, multi-agent, collaboration, workflow, pitfalls]
    related_skills: [kanban-orchestrator, restart-window-bundling]
---

# Kanban Worker — Pitfalls and Examples

> You're seeing this skill because the Hermes Kanban dispatcher spawned you as a worker with `--skills kanban-worker` — it's loaded automatically for every dispatched worker. The **lifecycle** (6 steps: orient → work → heartbeat → block/complete) also lives in the `KANBAN_GUIDANCE` block that's auto-injected into your system prompt. This skill is the deeper detail: good handoff shapes, retry diagnostics, edge cases.

## Development-task restart gate

For any task that plans, changes, reviews, publishes, deploys, updates, or configures software, `restart-window-bundling` must be loaded before implementation. Maintained dispatchers force-load it and fail closed on missing profile inventory; a worker on any other runtime must load and verify it explicitly. If the card omits any of `Restart impact`, `Target processes`, `Activation grouping`, classification `Evidence`, or `Rollback identity`, block and request those fields rather than guessing. Treat `unknown` as `restart_required`. Coding/review completion does not authorize intake pause, deployment, reload, restart, or reboot. Report only the reached state: `built`, `queued`, `sealed`, `activated`, or `observed`.

## Workspace handling

Your workspace kind determines how you should behave inside `$HERMES_KANBAN_WORKSPACE`:

| Kind | What it is | How to work |
|---|---|---|
| `scratch` | Fresh tmp dir, yours alone | Read/write freely; it gets GC'd when the task is archived. |
| `dir:<path>` | Shared persistent directory | Other runs will read what you write. Treat it like long-lived state. Path is guaranteed absolute (the kernel rejects relative paths). |
| `worktree` | Git worktree at the resolved path | If `.git` doesn't exist, run `git worktree add <path> <branch>` from the main repo first, then cd and work normally. Commit work here. |

## Review freshness and scope hygiene

For multi-phase engineering cards, a prior PASS is valid only for the exact commit and diff it reviewed. If the branch is rebased, receives new commits, or changes worktrees, report the old result as stale and rerun the relevant review rather than treating it as inherited approval.

Keep verification environments separate from product changes. If tests are unavailable, first locate the repository's established interpreter/venv and report the setup constraint. Do not run dependency resolution that edits `pyproject.toml`, lockfiles, or package metadata unless that change is explicitly in the task scope. Incidental dependency churn must be reverted or blocked before handoff.

A controller should independently read back the worker's current SHA, status/diff, changed-file list, test commands/results, and any live evidence. Do not rely solely on a worker summary, a completed status, or an old comment.

**Dirty-handoff recovery is a first-class gate.** A worker summary claiming a fix is complete is not an artifact handoff if the assigned worktree is dirty or no candidate SHA exists. If the implementation is valid but uncommitted, create a narrowly scoped commit-finalization task in the same persistent worktree, keep review dependency-blocked, and dispatch only after the finalizer verifies the exact SHA and clean status. Explicitly re-block any reviewer that was promoted before the SHA existed; never review an undefined candidate.

**Profile-health preflight precedes reviewer retries.** Repeated `pid not alive`, clean-exit protocol violations, or crash loops on a reviewer require a direct profile smoke: `hermes -p <profile> chat -Q -q 'Reply exactly: PROFILE_OK' --toolsets ''`. Distinguish provider/auth failure from worker logic failure. If the reviewer profile is unhealthy, preserve the artifact, reassign to a verified working reviewer, run `dispatch --dry-run --json`, dispatch one worker, and verify that the intended task is actually running.

### Exact-SHA review after iterative repair

When a candidate changes after review, the prior verdict is stale even if the new edit is one line. Create a fresh read-only review against the final immutable SHA, and repeat the focused regression that exposed the prior defect. For search/database repairs, test the result contract rather than only SQL execution: when results come from multiple sources (for example indexed and fallback rows), fetch enough from each source to cover `limit + offset`, merge, deduplicate, apply the requested global sort, and paginate only after the merge. Verify both sort directions, nonzero offsets, filters, and page consistency against an unpaginated reference. Never report a candidate PASS because focused/full tests pass if the exact final SHA has not received independent review. See `references/global-search-pagination-review.md` for the reusable probe and gate checklist.

### Controller-bound exact-SHA review and PR publication

After an implementation worker repairs findings, the controller must bind review to one immutable candidate—not merely to a task title, branch name, or worker summary. This is especially important when the implementation commit is amended after an initial review:

1. Read back the canonical candidate SHA, base SHA, workspace path, and worktree status.
2. Make the independent review workspace clean and exactly checked out at that candidate SHA. Remove only incidental generated artifacts such as test `__pycache__`; never discard unreviewed source changes silently.
3. Add a controller comment naming the exact `origin/main...HEAD` range and explicitly forbidding edits, push, merge, and deployment.
4. Dispatch the intended review task and verify the spawned task ID; `dispatch --max 1` is not task-specific.
5. Independently run the required test/syntax/diff checks in the builder checkout while review runs.
6. Read back the review's exact PASS/BLOCK summary, then re-check the candidate SHA and workspace state. A PASS on another SHA is stale.
7. Publish from the controller/publisher lane only after the independent PASS. Push `HEAD` to a descriptive branch, read back remote SHA parity, open the PR, and verify PR state/base/head/mergeability/checks.
8. Record the PR handle and exact SHA on the board. Keep merge, live installation, restart, and scheduler resumption as separate approval gates.

Do not treat “tests pass,” “task done,” or “PR open” as interchangeable with independent review, merge, or live state. For the reusable command/readback sequence, see `references/controller-bound-exact-sha-pr-publication.md`.

### Canonical candidate selection after iterative repairs

When multiple repair candidates exist, reconcile the graph and evidence before dispatching more work:

1. Identify each candidate's exact immutable SHA, parent/base, workspace, and review status.
2. Prefer the latest candidate with an independent PASS that covers the previously blocked invariant; do not keep a redundant review path attached merely because it was created later.
3. Preserve superseded candidates and BLOCK verdicts as audit evidence, but unlink them from downstream integration and stop/reclaim any review that is no longer needed.
4. Treat a candidate with an append-only fallback or merged result set as a different semantic design from a candidate that only adds a fallback query; do not infer that the latter inherits the former's ordering/pagination fix.
5. After graph cleanup, read back the integration task's parents and comments to ensure exactly one canonical artifact gates promotion.

**Dispatch target pitfall:** `dispatch --max 1` means “start one eligible task,” not “start the task I just created.” If several cards are ready, it may consume a different higher-priority card. Before dispatching a specific review, either use the task-specific dispatch/run mechanism if available or verify the resulting spawned task ID and reclaim/block the wrong run immediately. Creating a card with `--initial-status blocked` prevents premature execution only until it is explicitly unblocked; inspect its status immediately before and after unblocking.

**CLI syntax pitfall:** read the exact subcommand help before scripting state changes. Kanban reasons are positional after the task ID (with `--kind` as the only flag), while `--body` is the supported create payload and `--workspace dir:<absolute-path>` selects a persistent directory. Completion summaries are option-based: use `hermes kanban complete <task-id> --summary "..." --metadata '...'`; do not pass the summary as a positional argument. A rejected flag or ambiguous positional invocation must not be retried blindly—read back the task state and event log after every state-changing command.

**Post-review controller handoff:** When an integration worker blocks with `review-required:` and the independent reviewer later posts PASS to the integration card, the controller—not the reviewer—must read back the exact review comment, verify the candidate SHA/worktree/live base independently, then unblock and complete the integration card. Keep deployment/merge/restart as a separate explicit approval gate; a passed isolated candidate is not live code.

**Disk-pressure test recovery:** A broad pytest failure caused by a full runner filesystem is not evidence of a code failure. Preserve the original failure, then rerun deterministically with a clean temporary/cache surface, for example `TMPDIR=/dev/shm`, `--basetemp=/dev/shm/<unique-run>`, and `-p no:cacheprovider`; record both the original infrastructure failure and the successful clean rerun. Verify free space and clean the temporary artifacts before handoff. Do not silently call the first failed broad run a pass, and do not modify dependency metadata to work around runner storage pressure.

See `references/exact-sha-review-supersession.md` for the controller checklist and indexed/fallback ordering reproduction pattern. For persistence/routing repairs with remote-base drift, isolated SQLite canaries, point-write benchmarks, and separate publish/deploy/restart gates, use `references/routing-persistence-exact-sha-review.md`.

### Exact-SHA routing/persistence repair evidence

For a routing or SessionDB durability repair whose candidate was rebased after the initial review:

1. Reconcile the final candidate against the current canonical remote base. Verify the candidate's parent chain, clean status, changed-file list, and exact `HEAD`; do not inherit a prior PASS merely because the five functional blobs are unchanged.
2. If the remote advanced with unrelated canonical commits, rebase the repair onto that exact base, then rerun focused tests and obtain a fresh independent review bound to both candidate and base.
3. Use an isolated temporary Hermes home and temporary SQLite files for concurrency/failure canaries. A representative canary should cover concurrent point mutations, atomic startup/prune/reconciliation, failed upserts/deletes with generation non-advancement, writer races, JSON fallback, transient `InterfaceError` handling, no-loss/no-duplication reads, FD/thread cleanup, and scope-isolated deletion.
4. Record both row scale and resource evidence: row count, mutation count, SQLite integrity, no-loss/no-mismatch, WAL checkpoint, FD delta, and thread delta. If storage pressure causes a test-runner failure, preserve the original failure and rerun with a clean temporary surface such as `TMPDIR=/dev/shm`, `--basetemp=/dev/shm/<unique-run>`, and `-p no:cacheprovider`.
5. Benchmark the old full-replacement path against the candidate point-update path using the same representative row count. Report p50/p95/max and the speedup, not a qualitative claim.
6. Keep publication, live-checkout update, service restart, and acceptance/rollback verification as distinct gates. An isolated canary PASS authorizes none of them.

### Post-remediation event-loop lag attribution

When a previous production fix landed but current gateway lag persists, do not open another speculative implementation card. Start with one read-only, current-process attribution card bound to the exact live HEAD/PID and known landed controls; correlate every severe lag interval with SessionDB writes, Telegram/API/provider activity, subprocess/tool/cron activity, and stack dumps. Classify findings as trigger, amplifier, or victim and require a durable evidence report plus one narrow next patch target before implementation. Build the dependent PM/spec → isolated TDD worktree → exact-SHA review → disposable canary chain before dispatching. Keep attribution strictly free of restarts, config edits, git writes, DB writes, and heavy SQLite probes. See `references/post-remediation-event-loop-lag-chain.md` for the reusable task-body and handoff pattern.

### Fail-closed semantic verdicts and duplicate controllers

Kanban task state and the worker's semantic verdict are separate facts. A card marked `done` is not a PASS if its summary, metadata, or review report says `BLOCK`, `FAIL`, or identifies an acceptance defect. Before promoting or integrating, read the exact verdict and verify the reviewed SHA yourself; treat disagreement as BLOCK.

When several controller runs may act on one board, reconcile the board before creating work. Choose one canonical repair card and one dependent reviewer; archive or reclaim duplicates, unlink their downstream edges, and stop lingering worker processes so blocked workers cannot continue mutating shared workspaces. Do not dispatch a second implementation merely because an earlier card is blocked or slow.

After a failed review, prefer a fresh isolated `worktree` rooted at the canonical live/remote SHA. Never use a persistent `dir:` workspace for concurrent corrective work unless exclusive ownership is proved. A repair worker must commit in its assigned worktree and hand off the exact immutable SHA; the controller must verify clean status, ancestry, changed files, and SHA before dispatching review.

Production containment is a separate gate: if an accidental commit or dirty state reaches a live checkout, preserve the artifact on a clearly named branch, restore live to the verified remote SHA without restarting services, and independently verify live cleanliness, HEAD/remote equality, and service PID/state. Do not promote, push, deploy, or restart until a new isolated artifact passes a fresh fail-closed review. See `references/fts-remediation-containment.md` for a concrete reconciliation/checklist pattern.

## Tenant isolation

If `$HERMES_TENANT` is set, the task belongs to a tenant namespace. When reading or writing persistent memory, prefix memory entries with the tenant so context doesn't leak across tenants:

- Good: `business-a: Acme is our biggest customer`
- Bad (leaks): `Acme is our biggest customer`

## What each worker sees

A Kanban worker does **not** automatically receive the whole chat/session transcript. Its useful context is the task title/body, comments, parent task results/metadata, recent work by the same assignee, workspace path/type, auto-injected Kanban guidance, and any forced skills. Write task bodies and parent handoffs as if this is all the worker will know.

## Safety-gated infrastructure handoffs

For infrastructure recovery cards with approval gates, make the gate explicit in the task body and separate operator from reviewer work. Dispatch the operator first when the reviewer depends on a newly written artifact; create or dispatch the reviewer only after the artifact exists. The reviewer must be read-only and must verify live final state, not merely trust the operator summary. The controller should independently read back the artifact path, checksum it, and re-check the resource state before telling the user the operation passed. Keep the next production-action card blocked until the user explicitly approves the next gate; a successful clone or containment drill does not authorize secret/share use or production changes.

## Production installation and live-verification handoffs

For infrastructure cards that promote a reviewed artifact onto a live host, treat **merge, install, service execution, scheduler resumption, and live verification as separate gates**. A merged PR is not deployed, and a successful isolated test is not evidence that the live host is correct.

Recommended controller sequence:

1. Revalidate target identity, access path, clean source checkout, service idle state, and any freshness/GC preconditions immediately before the change.
2. Read back the exact immutable reviewed/merged SHA and expected file hashes. Fast-forward the durable checkout only to that SHA; refuse a dirty or unexpected candidate.
3. Create a timestamped, permission-restricted rollback bundle before installation. Include old installed files, generated metrics/cache artifacts, relevant unit definitions, and a state manifest with source HEAD, timer state, and hashes.
4. Install exact files with explicit ownership/mode and read them back by checksum.
5. Run the cheap exporter/textfile path first. This establishes whether legacy cache data is intentionally invalid or malformed before a slow refresh is attempted.
6. Start the guarded refresh once, without overlapping runs. A startup race or assertion about `activating` is not proof of failure: read back `ActiveState`, `SubState`, `Result`, `MainPID`, process/lock state, and journal markers before retrying.
7. Wait for completion using bounded polling and report progress from live state. Do not kill or retry a still-running scan merely because it exceeds an interactive patience window.
8. Run the exporter again, then verify exact invariants: cache/main metric parity, expected series count, freshness/validity gauges, scrape success, absence of duplicate-series errors, and service exit status.
9. Verify scheduler/unit configuration by comparing unit content and timer semantics; a manually started service can cause the timer's randomized next-fire timestamp to be recalculated, so do not call that a unit mutation without a unit-file diff/readback.
10. Record the rollback path, exact SHA/hashes, live evidence, and remaining blocked/superseded cards on the board. Use the CLI's actual state-changing verb (`complete`, not an invented alias); after any rejected command, read back state before retrying.

Reusable evidence commands and report shape: `references/production-install-live-verification.md`.

## Good task definitions include:

- **Goal** — what should be true when the task is done.
- **Context** — why this exists, prior report paths/task IDs, constraints.
- **Scope / non-scope** — exact inclusions and exclusions.
- **Inputs** — repos, hosts, namespaces, files, parent outputs.
- **Allowed actions** — e.g. read files, inspect git status, run read-only commands.
- **Forbidden or approval-gated actions** — e.g. edits, `kubectl apply/patch`, `helm upgrade`, installs, builds, Docker pulls/builds, dependency resolution, commits, pushes.
- **Deliverables** — structured inventory, findings list, proposed diff, verification report.
- **Completion criteria / block conditions** — how to know it is done and when to stop for human input.

Bad: `Audit supply chain and fix stuff.`

Good: `Run read-only supply-chain audit for /path/repo; include npm, Dockerfile, GitHub Actions; allowed: file reads/git status/static inspection; forbidden without approval: installs/builds/edits/commits/pushes; output findings with exact evidence, severity, and remediation.`

## Good summary + metadata shapes

The `kanban_complete(summary=..., metadata=...)` handoff is how downstream workers read what you did. Patterns that work:

**Coding task:**
```python
kanban_complete(
    summary="shipped rate limiter — token bucket, keys on user_id with IP fallback, 14 tests pass",
    metadata={
        "changed_files": ["rate_limiter.py", "tests/test_rate_limiter.py"],
        "tests_run": 14,
        "tests_passed": 14,
        "decisions": ["user_id primary, IP fallback for unauthenticated requests"],
    },
)
```

**Coding task that needs human review (review-required):**

For most code-changing tasks, the work isn't truly *done* until a human reviewer has eyes on it. Block instead of complete, with `reason` prefixed `review-required: ` so the dashboard surfaces the row as needing review. Drop the structured metadata (changed files, test counts, diff/PR url) into a comment first, since `kanban_block` only carries the human-readable reason — comments are the durable annotation channel. Reviewer either approves and runs `hermes kanban unblock <id>` (which re-spawns you with the comment thread for any follow-ups) or asks for changes via another comment.

```python
import json

kanban_comment(
    body="review-required handoff:\n" + json.dumps({
        "changed_files": ["rate_limiter.py", "tests/test_rate_limiter.py"],
        "tests_run": 14,
        "tests_passed": 14,
        "diff_path": "/path/to/worktree",  # or PR url if pushed
        "decisions": ["user_id primary, IP fallback for unauthenticated requests"],
    }, indent=2),
)
kanban_block(
    reason="review-required: rate limiter shipped, 14/14 tests pass — needs eyes on the user_id/IP fallback choice before merging",
)
```

Use `kanban_complete` only when the task is genuinely terminal — e.g. a one-line typo fix, a docs change with no functional consequences, or a research task where the artifact IS the writeup itself.

**Research task:**
```python
kanban_complete(
    summary="3 competing libraries reviewed; vLLM wins on throughput, SGLang on latency, Tensorrt-LLM on memory efficiency",
    metadata={
        "sources_read": 12,
        "recommendation": "vLLM",
        "benchmarks": {"vllm": 1.0, "sglang": 0.87, "trtllm": 0.72},
    },
)
```

**Review task:**
```python
kanban_complete(
    summary="reviewed PR #123; 2 blocking issues found (SQL injection in /search, missing CSRF on /settings)",
    metadata={
        "pr_number": 123,
        "findings": [
            {"severity": "critical", "file": "api/search.py", "line": 42, "issue": "raw SQL concat"},
            {"severity": "high", "file": "api/settings.py", "issue": "missing CSRF middleware"},
        ],
        "approved": False,
    },
)
```

Shape `metadata` so downstream parsers (reviewers, aggregators, schedulers) can use it without re-reading your prose.

## Claiming cards you actually created

If your run produced new kanban tasks (via `kanban_create`), pass the ids in `created_cards` on `kanban_complete`. The kernel verifies each id exists and was created by your profile; any phantom id blocks the completion with an error listing what went wrong, and the rejected attempt is permanently recorded on the task's event log. **Only list ids you captured from a successful `kanban_create` return value — never invent ids from prose, never paste ids from earlier runs, never claim cards another worker created.**

```python
# GOOD — capture return values, then claim them.
c1 = kanban_create(title="remediate SQL injection", assignee="security-worker")
c2 = kanban_create(title="fix CSRF middleware", assignee="web-worker")

kanban_complete(
    summary="Review done; spawned remediations for both findings.",
    metadata={"pr_number": 123, "approved": False},
    created_cards=[c1["task_id"], c2["task_id"]],
)
```

```python
# BAD — claiming ids you don't have captured return values for.
kanban_complete(
    summary="Created remediation cards t_a1b2c3d4, t_deadbeef",  # hallucinated
    created_cards=["t_a1b2c3d4", "t_deadbeef"],                   # → gate rejects
)
```

If a `kanban_create` call fails (exception, tool_error), the card was NOT created — do not include a phantom id for it. Retry the create, or omit the id and mention the failure in your summary. The prose-scan pass also catches `t_<hex>` references in your free-form summary that don't resolve; these don't block the completion but show up as advisory warnings on the task in the dashboard.

## Block reasons that get answered fast

Bad: `"stuck"` — the human has no context.

Good: one sentence naming the specific decision you need. Leave longer context as a comment instead.

```python
kanban_comment(
    task_id=os.environ["HERMES_KANBAN_TASK"],
    body="Full context: I have user IPs from Cloudflare headers but some users are behind NATs with thousands of peers. Keying on IP alone causes false positives.",
)
kanban_block(reason="Rate limit key choice: IP (simple, NAT-unsafe) or user_id (requires auth, skips anonymous endpoints)?")
```

The block message is what appears in the dashboard / gateway notifier. The comment is the deeper context a human reads when they open the task.

## Heartbeats worth sending

Good heartbeats name progress: `"epoch 12/50, loss 0.31"`, `"scanned 1.2M/2.4M rows"`, `"uploaded 47/120 videos"`.

Bad heartbeats: `"still working"`, empty notes, sub-second intervals. Every few minutes max; skip entirely for tasks under ~2 minutes.

## Retry scenarios

If you open the task and `kanban_show` returns `runs: [...]` with one or more closed runs, you're a retry. The prior runs' `outcome` / `summary` / `error` tell you what didn't work. Don't repeat that path. Typical retry diagnostics:

- `outcome: "timed_out"` — the previous attempt hit `max_runtime_seconds`. You may need to chunk the work or shorten it.
- `outcome: "crashed"` — OOM or segfault. Reduce memory footprint.
- `outcome: "spawn_failed"` + `error: "..."` — usually a profile config issue (missing credential, bad PATH). Ask the human via `kanban_block` instead of retrying blindly.
- `outcome: "reclaimed"` + `summary: "task archived..."` — operator archived the task out from under the previous run; you probably shouldn't be running at all, check status carefully.
- `outcome: "blocked"` — a previous attempt blocked; the unblock comment should be in the thread by now.

## Do NOT

- Call `delegate_task` as a substitute for `kanban_create`. `delegate_task` is for short reasoning subtasks inside YOUR run; `kanban_create` is for cross-agent handoffs that outlive one API loop.
- Modify files outside `$HERMES_KANBAN_WORKSPACE` unless the task body says to.
- Edit `~/.hermes/config.yaml`, `~/.hermes/profiles/*`, `SOUL.md`, memory files, or skills unless the task explicitly asks for profile/config/skill maintenance. A worker's profile is its operating policy; changing it mid-task is not normal task execution.
- Use persistent memory for ordinary task progress or findings. Put cross-task handoff material in `kanban_complete(summary=..., metadata=...)` or comments. Use memory only for stable facts/preferences; use skills for reusable procedures.
- Create follow-up tasks assigned to yourself — assign to the right specialist.
- Complete a task you didn't actually finish. Block it instead.

## Pitfalls

**Python venvs created by workers may not work on target VMs.** If your task involves deploying code to a remote VM (via rsync, scp, etc.) and the Hermes host uses `uv` or another managed Python, any `.venv/` you create will contain symlinks to binaries that don't exist on the target. The venv will appear valid on the Hermes host but produce `cannot execute: required file not found` or broken symlinks on the target. **Fix**: always recreate the venv on the target VM using its system Python (`python3 -m venv .venv`), then install deps via `.venv/bin/pip install`. Never rsync `.venv/` to a remote host.

**Task state can change between dispatch and your startup.** Between when the dispatcher claimed and when your process actually booted, the task may have been blocked, reassigned, or archived. Always `kanban_show` first. If it reports `blocked` or `archived`, stop — you shouldn't be running.

**Workspace may have stale artifacts.** Especially `dir:` and `worktree` workspaces can have files from previous runs. Read the comment thread — it usually explains why you're running again and what state the workspace is in.

**Iteration budget exhaustion.** Workers have a limited tool-call budget (typically 60 iterations). If your task involves processing many items (200+), you will likely exhaust the budget before completing. **Do not** try to process everything in one go. Instead:

1. **Chunk the work** — process items in batches of 40-50
2. **Report partial progress** — use `kanban_block` with `reason: "iteration-budget: processed N/M items, handoff for continuation"` and include the processed subset in metadata
3. **Let the orchestrator create parallel micro-batches** — the orchestrator should split the task into parallel micro-batches, not the worker

If you hit the budget unexpectedly, add a comment with:
- How many items were processed
- Where the remaining items start
- Any partial artifacts produced
- The next item to process

This allows the orchestrator to either unblock you (if the work can continue) or create parallel micro-batches (if the remaining work is independent).

**External approval gates during review.** If a final verifier is blocked only because a live-readonly smoke needs a human-gated auth step (for example a Tailscale SSH additional-check link), do not complete the review on deterministic tests alone when live verification is part of the acceptance criteria. Block with a precise `live-smoke-blocked:` reason naming the host/service and approval needed. After the controller/user clears the gate, unblock and rerun the live smoke; then complete only with fresh evidence from the post-approval run.

**Repeated provider/protocol failures are an orchestration blocker, not a reason to retry forever.** If a worker repeatedly exits cleanly without `kanban_complete`/`kanban_block`, hits provider 429/401 loops, or crashes before it can summarize despite producing useful partial terminal output, the orchestrator should stop re-dispatching the same broad card. Create a bounded rescue card or run a deterministic script from the orchestrator session, write markdown/JSON artifacts, and complete/supersede the wedged verification card with explicit metadata pointing to those artifacts. Preserve real remaining service blockers as separate cards; do not let a protocol failure masquerade as an infrastructure failure.

**Repeated protocol/provider failures on verification cards.** If a broad verifier repeatedly exits without `kanban_complete`/`kanban_block`, hits provider 429s, or otherwise trips the circuit breaker while the underlying work can be checked deterministically, do not keep redispatching the same long agent card. The orchestrator should create or perform a bounded rescue verification: run deterministic checks directly (API health, counts, key artifacts, representative queries), write durable rescue artifacts, then complete the wedged verifier as superseded by those artifacts. Keep any real unresolved service/exporter work as separate explicit blocked cards. This distinguishes infrastructure/work blockers from agent/provider protocol failures and prevents a board from staying wedged.

**Parallel micro-batch awareness.** When running as part of a parallel micro-batch:
- Your task body should explicitly state: "This is micro-batch X of Y. Processing items N-M."
- Write outputs to an isolated subdirectory: `staging/batch-X/`
- Do not read from or write to other batches' directories
- Report completion with counts: "Processed 50/50 items in batch X"
- If you finish early, report success; if you hit issues, report which items failed and why

**Don't rely on the CLI when the guidance is available.** The `kanban_*` tools work across all terminal backends (Docker, Modal, SSH). `hermes kanban <verb>` from your terminal tool will fail in containerized backends because the CLI isn't installed there. When in doubt, use the tool.

**Scope-conflict during final verification.** If your scoped change is complete but the required full-suite command fails on an unrelated sibling fix (for example another Axis-D test created by a different card), do not sit in an interactive clarification loop. Add a concise comment with: your scoped files touched, targeted RED/GREEN output, the unrelated failing test name/output, and the exact command that failed; then block with a `scope-conflict:` reason. The controller can either fix the shared blocker once and complete your card with full-suite evidence, or explicitly expand your scope. This avoids burning runtime waiting for a human answer inside a worker session.

**Profile-local cache duplication.** Worker profiles can grow large when `HOME` resolves to `~/.hermes/profiles/<profile>/home` and package/browser tools independently populate `.bun/install/cache`, `.npm/_cacache`, `.cache/uv`, `.cache/pnpm`, `.cache/ms-playwright`, `.cache/electron`, or `.agent-browser/browsers` in every profile. For storage investigations, first measure profile homes and cache dirs read-only; do not delete profile state/auth/workspaces. Prefer sharing heavyweight caches via a central shell init file referenced from `terminal.shell_init_files`, while preserving per-profile `HERMES_HOME` for config/auth/state. See `references/profile-cache-sharing.md` for the evidence commands, shared-cache env variables, smoke tests, cleanup gates, and the longer-term `kanban.worker_env` core-improvement shape.

**SSH terminal backend (remote compute offload).** When a worker profile has `terminal.backend: ssh` configured, all `terminal()`, `read_file()`, `write_file()`, `search_files()`, and `execute_code()` calls are transparently proxied to a remote host over SSH (ControlMaster-persisted). The worker process itself runs locally (on the Hermes VM), but heavy compute executes on the remote machine. Key behaviors:
- DB access (`kanban_*` tools) stays local on the Hermes VM — direct SQLite, correct locking, no NFS issues.
- File sync: `~/.hermes/` (skills, credentials, config) is automatically synced to the remote host on first connect and hash-diffed on subsequent calls.
- PID-based crash detection still works — the local hermes process IS the worker; if it dies, SSH sessions terminate too.
- Per-command latency: ~50-100ms per tool call for SSH round-trip. Negligible for LLM-driven workloads.
- The remote host must have: SSH key auth configured, Python 3, and basic tools (`bash`, `coreutils`). Hermes does NOT need to be installed on the remote.
- Do NOT attempt to access the Kanban DB directly from the remote terminal (e.g., `sqlite3 ~/.hermes/kanban/...` over SSH) — the DB path on the remote is for file-sync only, not direct DB access. Use the `kanban_*` tools instead.

## CLI fallback (for scripting)

Every tool has a CLI equivalent for human operators and scripts:
- `kanban_show` ↔ `hermes kanban show <id> --json`
- `kanban_complete` ↔ `hermes kanban complete <id> --summary "..." --metadata '{...}'`
- `kanban_block` ↔ `hermes kanban block <id> "reason"`
- `kanban_create` ↔ `hermes kanban create "title" --assignee <profile> [--parent <id>]`
- etc.

Use the tools from inside an agent; the CLI exists for the human at the terminal.
