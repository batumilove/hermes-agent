# Routing/Persistence Exact-SHA Review Reference

Use this reference for SessionDB/gateway routing durability repairs where the candidate is rebased, storage pressure affects test execution, and production promotion is approval-gated.

## Immutable candidate procedure

1. Read back the canonical remote/live base and candidate SHA from the clean worktree.
2. If the remote base advanced with unrelated canonical commits, rebase the repair onto that base. Verify the final parent chain and `git status --short --branch`.
3. Treat all earlier review results as stale after the rebase. Obtain a fresh independent review explicitly bound to both final candidate and base.
4. Compare the functional blobs against the previously reviewed candidate with SHA-256 or Git blob IDs. This proves scope preservation; it does not replace the fresh review.

Useful readbacks:

```bash
git rev-parse HEAD
git rev-parse HEAD^
git status --short --branch
git diff --stat <base>..<candidate>
git diff --name-only <base>..<candidate>
for f in <changed-files>; do
  test "$(git rev-parse <candidate>:$f)" = "$(git rev-parse <prior-reviewed>:$f)"
done
```

## Test recovery under disk pressure

Preserve the first failure as infrastructure evidence. Rerun without pytest cache and with a unique tmp surface; do not change dependency metadata:

```bash
TMPDIR=/dev/shm python -m pytest <focused-tests> \
  -o 'addopts=' -q -p no:cacheprovider \
  --basetemp=/dev/shm/routing-review-<pid>
```

A successful rerun does not erase the original failure; report both.

## Disposable canary contract

Use a fresh temporary `HERMES_HOME` and SQLite files. Never point the canary at the production profile or database. Minimum suites:

- concurrent point mutations at representative scale;
- atomic startup, stale-entry pruning, and reconciliation;
- injected failed/partial point upserts and deletes, proving generation/baseline do not advance on failure;
- out-of-order writer/generation races;
- `sessions.json` fallback when DB is unavailable or fails;
- transient, exhausted, and unrelated `sqlite3.InterfaceError` behavior;
- concurrent save/load no-loss and no-duplication checks;
- repeated start/stop with FD/thread leak checks and WAL integrity;
- routing-scope isolation and exact-key deletion.

Record row count, mutation count, integrity result, mismatch/loss/duplicate counts, WAL checkpoint, FD delta, thread delta, and total checks passed/failed. A canary PASS is isolated evidence only.

## Performance evidence

Benchmark old full replacement and candidate point update against the same representative row count and sample count. Report p50, p95, max, and calculated speedup. Avoid comparing different storage locations or warmup conditions without stating that limitation.

## Promotion gates

Keep these separate and explicit:

1. independent exact-SHA review;
2. publish/push candidate to the remote feed;
3. update the live checkout to the exact published SHA;
4. restart the service;
5. post-restart live acceptance and rollback verification.

No isolated test or review authorizes a later gate. Record the exact SHA and read back state after every state-changing command.

## CLI pitfall

Before scripting Kanban state changes, read the exact subcommand help. `hermes kanban comment` takes the task ID and comment text positionally; `--body` is not valid for that verb. If a command is rejected, do not blindly retry: inspect help, then read back task state/event history after the corrected state-changing command.
