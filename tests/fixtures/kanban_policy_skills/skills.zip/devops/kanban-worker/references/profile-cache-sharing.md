# Kanban Worker Profile Cache Sharing

Use this reference when Kanban worker profile homes grow because each profile maintains its own package/browser caches under `~/.hermes/profiles/<profile>/home`.

## Symptom

Worker profiles have isolated `HERMES_HOME` values and, on container-like/local installs, terminal subprocesses may resolve `HOME` to:

```text
~/.hermes/profiles/<profile>/home
```

Package managers and browser installers then duplicate heavyweight caches per profile:

```text
.bun/install/cache
.npm/_cacache
.cache/uv
.cache/pnpm
.cache/ms-playwright
.cache/electron
.agent-browser/browsers
.local/share
```

Typical evidence commands, read-only:

```bash
du -xhd1 ~/.hermes/profiles 2>/dev/null | sort -h | tail -30
for p in ~/.hermes/profiles/*/home; do du -sxh "$p" 2>/dev/null; done | sort -h | tail -30
du -sxh ~/.hermes/profiles/*/home/.bun/install/cache \
  ~/.hermes/profiles/*/home/.npm/_cacache \
  ~/.hermes/profiles/*/home/.cache/uv \
  ~/.hermes/profiles/*/home/.cache/pnpm \
  ~/.hermes/profiles/*/home/.cache/ms-playwright \
  ~/.hermes/profiles/*/home/.cache/electron \
  ~/.hermes/profiles/*/home/.agent-browser/browsers 2>/dev/null | sort -h | tail -80
```

Also check whether a shared cache root already exists:

```bash
du -xhd1 ~/.hermes/shared-caches 2>/dev/null | sort -h || true
```

## Root cause

Kanban workers are spawned through `hermes_cli/kanban_db.py::_default_spawn()` as:

```text
hermes -p <profile> --accept-hooks ... chat -q "work kanban task <id>"
```

The dispatcher injects profile-scoped env such as:

```text
HERMES_HOME=~/.hermes/profiles/<profile>
HERMES_PROFILE=<profile>
HERMES_KANBAN_TASK=...
HERMES_KANBAN_WORKSPACE=...
```

When Hermes' subprocess HOME policy chooses the profile home, uncaptured package-manager defaults become profile-local. `terminal.env_passthrough` is not enough by itself: it passes existing variables through; it does not define new shared cache variables.

## Safe target architecture

Keep profile isolation for config/auth/state, but share heavyweight caches:

```text
~/.hermes/shared-caches/bun
~/.hermes/shared-caches/npm
~/.hermes/shared-caches/pnpm-home
~/.hermes/shared-caches/xdg
~/.hermes/shared-caches/uv
~/.hermes/shared-caches/playwright
~/.hermes/shared-caches/electron
~/.hermes/shared-caches/agent-browser
```

Useful env variables:

```bash
export HERMES_SHARED_CACHE="$HOME/.hermes/shared-caches"
export BUN_INSTALL_CACHE_DIR="$HERMES_SHARED_CACHE/bun"
export npm_config_cache="$HERMES_SHARED_CACHE/npm"
export PNPM_HOME="$HERMES_SHARED_CACHE/pnpm-home"
export XDG_CACHE_HOME="$HERMES_SHARED_CACHE/xdg"
export UV_CACHE_DIR="$HERMES_SHARED_CACHE/uv"
export PLAYWRIGHT_BROWSERS_PATH="$HERMES_SHARED_CACHE/playwright"
export electron_config_cache="$HERMES_SHARED_CACHE/electron"
export ELECTRON_CACHE="$HERMES_SHARED_CACHE/electron"
mkdir -p "$BUN_INSTALL_CACHE_DIR" "$npm_config_cache" "$PNPM_HOME" "$XDG_CACHE_HOME" "$UV_CACHE_DIR" "$PLAYWRIGHT_BROWSERS_PATH" "$ELECTRON_CACHE"
```

Prefer a shared shell init file, for example `~/.hermes/kanban-worker-cache-env.sh`, and add it to `terminal.shell_init_files` for selected worker profiles. This avoids hand-editing multiple `.bashrc` files and uses Hermes' existing shell-env snapshot mechanism.

## Smoke verification

For each target profile, use a real profile launch or a Kanban canary and confirm terminal subprocess output:

```bash
echo "$HOME"
echo "$HERMES_HOME"
echo "$BUN_INSTALL_CACHE_DIR"
npm config get cache
uv cache dir
echo "$PLAYWRIGHT_BROWSERS_PATH"
echo "$electron_config_cache"
```

Expected after the change: npm/uv/browser cache paths point under `~/.hermes/shared-caches`, while `HERMES_HOME` remains profile-specific.

## Cleanup policy

Do **not** delete first. After env smoke passes and no workers are actively using the old dirs, request explicit approval for cache-only cleanup. Candidate cache-only paths include:

```text
~/.hermes/profiles/<profile>/home/.bun/install/cache
~/.hermes/profiles/<profile>/home/.npm/_cacache
~/.hermes/profiles/<profile>/home/.cache/uv
~/.hermes/profiles/<profile>/home/.cache/pnpm
~/.hermes/profiles/<profile>/home/.cache/ms-playwright
~/.hermes/profiles/<profile>/home/.cache/electron
~/.hermes/profiles/<profile>/home/.agent-browser/browsers
```

Avoid deleting profile state/auth/workspaces such as `.ssh`, `.config`, credentials, project checkouts, `node_modules` inside active workspaces, or arbitrary `.local/share` without inspection.

## Long-term core improvement

A durable Hermes improvement would be a config-driven worker env block, for example:

```yaml
kanban:
  worker_env:
    HERMES_SHARED_CACHE: /home/ubuntu/.hermes/shared-caches
    BUN_INSTALL_CACHE_DIR: /home/ubuntu/.hermes/shared-caches/bun
    npm_config_cache: /home/ubuntu/.hermes/shared-caches/npm
    UV_CACHE_DIR: /home/ubuntu/.hermes/shared-caches/uv
    PLAYWRIGHT_BROWSERS_PATH: /home/ubuntu/.hermes/shared-caches/playwright
```

Injected in `_default_spawn()` before `subprocess.Popen`, this would make worker cache sharing central rather than per-profile shell setup.

## Adjacent robustness pitfall

If launching `hermes -p <profile> chat ...` from a deleted current directory, some builds can fail early in `cli.py` at `os.getcwd()` before terminal cwd repair. Launch profile smokes from a known-good cwd such as `/home/ubuntu` until that core robustness bug is fixed.