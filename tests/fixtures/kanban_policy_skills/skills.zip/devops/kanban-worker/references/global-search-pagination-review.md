# Global multi-source search pagination review

Use this reference when a search result is assembled from an indexed path plus fallback/excluded rows (for example byte-policy exclusions, tool messages, or a second database table).

## Contract

The public result must be globally correct, not merely correct within each SQL source:

1. Build a fixture containing at least one indexed hit, one fallback hit, and one tool-role or otherwise filtered hit.
2. Place timestamps so source-local ordering disagrees with the desired global ordering.
3. Exercise `newest` and `oldest`.
4. Exercise `limit` with `offset > 0`.
5. Compare each page with slicing an unpaginated result, and assert no duplicates.
6. Repeat relevant source/exclude/role/active filters.

A safe implementation generally requests an unsliced merge window from every contributing source, merges and deduplicates by stable row identity, sorts globally, then applies offset/limit once. Applying `OFFSET` independently in each source can drop or duplicate rows at page boundaries.

## Exact-SHA gate

Before accepting a repair:

- Confirm `HEAD` equals the worker-reported SHA.
- Confirm the worktree is clean and the SHA descends from the intended canonical base.
- Confirm the diff is bounded and contains no dependency churn or unrelated test deletion.
- Run the focused regression, the owning module suite, adjacent integration suites, lint/compile, and `git diff --check` from that exact checkout.
- Run a small bounded benchmark or smoke that reports hit count, sort correctness, page consistency, median latency, and maximum latency.
- Re-review after every commit or worktree change; earlier PASS evidence is stale.

## Fail-closed interpretation

A worker's `done` state, a passing test count, or a clean worktree is not an approval by itself. Any mismatch between the claimed SHA, actual SHA, semantic verdict, or acceptance contract is BLOCK. Keep integration, canary/soak, and production promotion as separate downstream gates.
