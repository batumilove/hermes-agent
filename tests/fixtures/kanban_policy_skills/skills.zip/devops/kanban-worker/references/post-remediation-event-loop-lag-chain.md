# Post-remediation event-loop lag chain

Use this pattern when a prior production remediation claimed to remove a hot-path SQLite/FTS or provider stall but live lag persists.

## Controller sequence

1. Create one read-only attribution card first. Bind it to the exact live checkout, branch, HEAD, gateway PID/start time, current lag/write counts, and known landed controls.
2. Make attribution explicitly current-process scoped. Re-correlate every >=30s lag interval; do not recycle the old diagnosis unless current timestamps and stacks prove it.
3. Require a durable artifact with exact commands, timestamps, counts, stack-dump paths, current source checks, ranked trigger/amplifier/victim hypotheses, confidence, missing instrumentation, and one narrow next patch target.
4. Create dependent PM/spec, implementation, review, and canary cards before dispatch. Keep implementation/review/canary blocked on the preceding artifact or verdict.
5. Use isolated `worktree` for code changes; use `scratch` for read-only attribution/spec/canary artifacts; reserve shared `dir:` for one exclusive owner only.
6. Dispatch one intended card and read back the spawned task ID, task status, run PID, profile, and workspace. `dispatch --max 1` selects any eligible card; it is not task-specific.
7. Independently verify the worker's progress and artifact path. A running worker with real command/log progress is not completion; an absent artifact is expected until the worker finishes.

## Attribution scope

Correlate lag windows against:

- enriched SessionDB write intervals and lock/transaction latency;
- Telegram network, connection-pool, timeout and retry warnings;
- provider/API/Codex first-byte and stream calls;
- subprocess, tool, cron and scheduler activity;
- stack-dump paths, event-loop thread state, and dominant worker stacks;
- already-landed routing, bounded queue, FTS and checkpoint controls.

Classify each hypothesis as **trigger** (blocks or monopolizes the loop), **amplifier** (increases duration/frequency/contention), or **victim** (symptom delayed by another blocker). Report confidence and explicitly say when evidence is insufficient.

## Safety gates

Attribution is read-only: no service restart/stop, config edits, git writes, DB writes, `VACUUM`, `quick_check`, `integrity_check`, `dbstat`, optimize, checkpoint, backup, or heavy state.db probe. Provider silent-hang fixes and pre-remediation FTS/checkpoint explanations must not be duplicated without fresh evidence.

## Handoff gates

- The PM/spec card consumes the attribution artifact and names the smallest patch target.
- The builder starts RED tests against the exact current base, then GREEN implementation, and returns an immutable commit SHA plus clean worktree.
- The reviewer binds to that exact SHA/base/diff; any amendment or rebase makes an earlier verdict stale.
- The canary runs only after independent PASS, preferably against a disposable database and synthetic concurrency/failure paths.
- Merge, installation, restart, scheduler resumption, and live acceptance remain separate approval gates.

## Session-specific anchor

The 2026-07-19 chain used board `gateway-loop-lag-remediation-20260717`, with attribution task `t_4fbdef7d` and dependent cards for PM/spec, TDD implementation, exact-SHA review, and disposable canary. Treat those IDs as historical examples only, not reusable identifiers.
