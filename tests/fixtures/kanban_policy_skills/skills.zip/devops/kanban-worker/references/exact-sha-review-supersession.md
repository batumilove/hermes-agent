# Exact-SHA Review Supersession

Use this when a board has several successive repairs for the same defect.

## Controller checklist

1. Record candidate SHA, intended base, parent chain, workspace, changed files, and review task.
2. Read the candidate directly: `git status --short --branch`, `git rev-parse HEAD`, ancestry check, diff stat/name-status, and protected-file deletion audit.
3. Require the reviewer to inspect the exact immutable SHA read back by the controller. A PASS on an earlier SHA is stale after any commit, rebase, worktree change, or semantic repair.
4. If a newer candidate independently passes the previously blocked invariant, make it canonical: unlink superseded review/integration edges, preserve the old BLOCK as evidence, and stop/reclaim redundant work before it mutates a shared workspace.
5. Read back the downstream integration task and confirm it has exactly the canonical PASS artifact as its FTS/search parent. A card's `done` state cannot override a `BLOCK` verdict in its summary or comments.
6. Keep production and the canonical live checkout unchanged until the final integrated SHA receives its own review and canary/ops gate.

## Indexed + fallback search reproduction

A fallback query that only runs when the indexed page has spare capacity is not globally correct. Construct a temporary database with:

- one newest large non-tool CJK row excluded from trigram indexing by the UTF-8 byte cap;
- at least `limit` older short rows that are trigram-indexed and match the same query;
- optional tool and filter-excluded rows.

Then compare `search_messages(query, limit=N, sort="newest")` with an unpaginated reference. The newest excluded row must appear before older indexed rows even when the indexed results alone fill the page. Repeat for `oldest`, nonzero offsets, source/exclude-source, role, active/compacted filters, deduplication, and page concatenation. The correct implementation merges enough candidates from both sources, applies one global ordering, then paginates.

## Dispatch safety

`dispatch --max 1` starts one eligible card, not necessarily the card just created. With several ready tasks, verify the spawned task ID immediately. Create sensitive/spec-heavy cards with `--initial-status blocked`, inspect them before adding context, and unblock only when the intended worker/review path is ready. For CLI automation, consult the exact subcommand help: reasons are positional; `--workspace dir:<absolute-path>` is the persistent-directory form; do not invent `--reason`, `--body-file`, or task-specific dispatch flags without checking support.
