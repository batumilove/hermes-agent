# Controller-bound exact-SHA review and PR publication

Use this after a builder has amended a candidate in response to review findings. The goal is to prevent a valid review from accidentally applying to a stale commit, dirty workspace, or different remote branch.

## Controller checklist

1. **Bind the candidate**
   - Read `HEAD`, `origin/main`, ancestry, worktree status, changed-file list, and workspace path.
   - If the reviewer workspace is stale or dirty, clean only generated artifacts and check it out at the exact candidate SHA.
   - Do not let a reviewer inspect an undefined or moving candidate.

2. **Constrain the review**
   - Comment the exact range, for example `origin/main...74c2b6f`.
   - State: read-only review; do not modify, push, merge, or deploy.
   - Dispatch the intended task, then verify the resulting spawned task ID. `dispatch --max 1` means one eligible task, not necessarily the requested one.

3. **Verify independently**
   - In the builder checkout, run the required focused/full tests, syntax checks, and `git diff --check`.
   - Remove test-generated artifacts and verify a clean worktree.
   - Wait for the independent reviewer and read its exact semantic verdict, not just Kanban status.

4. **Publish only after PASS**
   - Fetch `origin/main` again and verify the base has not moved.
   - Push the reviewed `HEAD` to a descriptive branch from the controller/publisher lane.
   - Read back the remote branch SHA and require exact equality with local `HEAD`.
   - Create the PR and read back: URL/number, open state, base SHA, head SHA, mergeability, merge state, and CI checks.

5. **Preserve approval boundaries**
   - Record the PR URL and exact SHA in the board comments.
   - Keep merge, production checkout installation, service restart, and scheduler resumption as distinct gates.
   - A clean/mergeable PR is not merged code; a merged PR is not live code.

## Minimal readback shape

```text
candidate_sha: <immutable SHA>
base_sha:      <origin/main SHA>
worktree:      clean
review:        PASS on exact candidate_sha
remote_sha:    exact match
PR:            OPEN, head/base verified
checks:        explicit pass/fail counts
live state:    unchanged
next gate:     explicit merge or deployment approval
```

## Common failure modes

- Reviewer checked an earlier commit: rerun review; never inherit the old PASS.
- Reviewer worktree contains generated `__pycache__` or other incidental output: remove only known generated artifacts, then verify clean status and exact SHA.
- `dispatch --max 1` starts a different ready card: reclaim/block the wrong run and verify the intended task before continuing.
- Worker says “done” but the semantic result is BLOCK/FAIL: treat it as blocked and create the narrow repair/re-review path.
- PR is mergeable but CI is absent or pending: report the actual check state; do not call it verified.
- PR is open at a different SHA than the reviewed candidate: stop and republish/review the exact remote head.
