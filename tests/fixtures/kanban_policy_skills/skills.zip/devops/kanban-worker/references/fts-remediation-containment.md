# FTS remediation containment and reconciliation pattern

Session-specific reference for a recurring class of Kanban work: a reviewed database/search repair is blocked, an implementation may have touched the wrong checkout, and multiple controller runs may race to create replacement cards.

## Controller checklist

1. Read the board before dispatching: list active/running/blocked cards, inspect parent/child edges, and read the semantic verdicts in comments and summaries.
2. Select one canonical repair path. Reclaim/archive duplicate builders and reviewers, unlink duplicate downstream edges, and terminate any worker process that remains alive after its card is blocked or reclaimed.
3. Start the repair in a new Git worktree from the exact canonical live/remote SHA. Do not reuse a persistent `dir:` workspace with dirty artifacts.
4. Give the builder a strict handoff contract: RED-GREEN tests for every prior review defect, no production mutation, one local commit, and exact SHA plus evidence.
5. Before review, independently verify:
   - `git status --short` is empty;
   - `HEAD` is the reported SHA;
   - the SHA is descended from the intended canonical base;
   - changed files and diff match scope;
   - no push, deploy, restart, dependency churn, or production DB/index mutation occurred.
6. Dispatch a read-only reviewer against that exact worktree/SHA. A card's `done` state never overrides a `BLOCK` verdict.
7. Only after a literal reviewer PASS may an integration card be promoted. Keep deployment/canary cards blocked until their explicit approval gate is satisfied.

## If live checkout contamination occurs

- Stop further writes immediately and identify the exact accidental SHA.
- Preserve it on a clearly named branch such as `preserve/fts-blocked-<shortsha>`.
- Restore the live checkout to the verified remote SHA without restarting the service.
- Verify live status is clean, live HEAD equals remote, the preserved branch resolves to the accidental SHA, and the service remains active with its existing PID/state.
- Keep the preserved artifact available only as source material; do not call it an accepted candidate.

## Failure patterns this prevents

- Treating a review card marked `done` as approval when its report says BLOCK.
- Building a correction in a shared dirty directory while a second worker uses the same files.
- Trusting a worker's claimed commit when the checkout HEAD and status contradict it.
- Letting a blocked worker process continue writing after its task was superseded.
- Promoting, restarting, or deploying merely because production containment succeeded.
